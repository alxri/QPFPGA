-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
-- Tool Version Limit: 2024.11
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
-- 
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity admm_control_r_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 9;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    A_row_idx             :out  STD_LOGIC_VECTOR(63 downto 0);
    A_col_ptr             :out  STD_LOGIC_VECTOR(63 downto 0);
    A_values              :out  STD_LOGIC_VECTOR(63 downto 0);
    A_tile_nnz_counts     :out  STD_LOGIC_VECTOR(63 downto 0);
    A_tile_nnz_offsets    :out  STD_LOGIC_VECTOR(63 downto 0);
    A_tile_col_offsets    :out  STD_LOGIC_VECTOR(63 downto 0);
    A_row_idx_tiled       :out  STD_LOGIC_VECTOR(63 downto 0);
    A_col_ptr_tiled       :out  STD_LOGIC_VECTOR(63 downto 0);
    A_values_tiled        :out  STD_LOGIC_VECTOR(63 downto 0);
    AT_tile_nnz_counts    :out  STD_LOGIC_VECTOR(63 downto 0);
    AT_tile_nnz_offsets   :out  STD_LOGIC_VECTOR(63 downto 0);
    AT_tile_col_offsets   :out  STD_LOGIC_VECTOR(63 downto 0);
    AT_row_idx_tiled      :out  STD_LOGIC_VECTOR(63 downto 0);
    AT_col_ptr_tiled      :out  STD_LOGIC_VECTOR(63 downto 0);
    AT_values_tiled       :out  STD_LOGIC_VECTOR(63 downto 0);
    P_tile_nnz_counts     :out  STD_LOGIC_VECTOR(63 downto 0);
    P_tile_nnz_offsets    :out  STD_LOGIC_VECTOR(63 downto 0);
    P_tile_col_offsets    :out  STD_LOGIC_VECTOR(63 downto 0);
    P_row_idx_tiled       :out  STD_LOGIC_VECTOR(63 downto 0);
    P_col_ptr_tiled       :out  STD_LOGIC_VECTOR(63 downto 0);
    P_values_tiled        :out  STD_LOGIC_VECTOR(63 downto 0);
    P_diag                :out  STD_LOGIC_VECTOR(63 downto 0);
    l_in                  :out  STD_LOGIC_VECTOR(63 downto 0);
    u_in                  :out  STD_LOGIC_VECTOR(63 downto 0);
    q_in                  :out  STD_LOGIC_VECTOR(63 downto 0);
    rho_in                :out  STD_LOGIC_VECTOR(63 downto 0);
    x_out                 :out  STD_LOGIC_VECTOR(63 downto 0);
    y_out                 :out  STD_LOGIC_VECTOR(63 downto 0)
);
end entity admm_control_r_s_axi;

-- ------------------------Address Info-------------------
-- Protocol Used: ap_ctrl_none
--
-- 0x000 : reserved
-- 0x004 : reserved
-- 0x008 : reserved
-- 0x00c : reserved
-- 0x010 : Data signal of A_row_idx
--         bit 31~0 - A_row_idx[31:0] (Read/Write)
-- 0x014 : Data signal of A_row_idx
--         bit 31~0 - A_row_idx[63:32] (Read/Write)
-- 0x018 : reserved
-- 0x01c : Data signal of A_col_ptr
--         bit 31~0 - A_col_ptr[31:0] (Read/Write)
-- 0x020 : Data signal of A_col_ptr
--         bit 31~0 - A_col_ptr[63:32] (Read/Write)
-- 0x024 : reserved
-- 0x028 : Data signal of A_values
--         bit 31~0 - A_values[31:0] (Read/Write)
-- 0x02c : Data signal of A_values
--         bit 31~0 - A_values[63:32] (Read/Write)
-- 0x030 : reserved
-- 0x034 : Data signal of A_tile_nnz_counts
--         bit 31~0 - A_tile_nnz_counts[31:0] (Read/Write)
-- 0x038 : Data signal of A_tile_nnz_counts
--         bit 31~0 - A_tile_nnz_counts[63:32] (Read/Write)
-- 0x03c : reserved
-- 0x040 : Data signal of A_tile_nnz_offsets
--         bit 31~0 - A_tile_nnz_offsets[31:0] (Read/Write)
-- 0x044 : Data signal of A_tile_nnz_offsets
--         bit 31~0 - A_tile_nnz_offsets[63:32] (Read/Write)
-- 0x048 : reserved
-- 0x04c : Data signal of A_tile_col_offsets
--         bit 31~0 - A_tile_col_offsets[31:0] (Read/Write)
-- 0x050 : Data signal of A_tile_col_offsets
--         bit 31~0 - A_tile_col_offsets[63:32] (Read/Write)
-- 0x054 : reserved
-- 0x058 : Data signal of A_row_idx_tiled
--         bit 31~0 - A_row_idx_tiled[31:0] (Read/Write)
-- 0x05c : Data signal of A_row_idx_tiled
--         bit 31~0 - A_row_idx_tiled[63:32] (Read/Write)
-- 0x060 : reserved
-- 0x064 : Data signal of A_col_ptr_tiled
--         bit 31~0 - A_col_ptr_tiled[31:0] (Read/Write)
-- 0x068 : Data signal of A_col_ptr_tiled
--         bit 31~0 - A_col_ptr_tiled[63:32] (Read/Write)
-- 0x06c : reserved
-- 0x070 : Data signal of A_values_tiled
--         bit 31~0 - A_values_tiled[31:0] (Read/Write)
-- 0x074 : Data signal of A_values_tiled
--         bit 31~0 - A_values_tiled[63:32] (Read/Write)
-- 0x078 : reserved
-- 0x07c : Data signal of AT_tile_nnz_counts
--         bit 31~0 - AT_tile_nnz_counts[31:0] (Read/Write)
-- 0x080 : Data signal of AT_tile_nnz_counts
--         bit 31~0 - AT_tile_nnz_counts[63:32] (Read/Write)
-- 0x084 : reserved
-- 0x088 : Data signal of AT_tile_nnz_offsets
--         bit 31~0 - AT_tile_nnz_offsets[31:0] (Read/Write)
-- 0x08c : Data signal of AT_tile_nnz_offsets
--         bit 31~0 - AT_tile_nnz_offsets[63:32] (Read/Write)
-- 0x090 : reserved
-- 0x094 : Data signal of AT_tile_col_offsets
--         bit 31~0 - AT_tile_col_offsets[31:0] (Read/Write)
-- 0x098 : Data signal of AT_tile_col_offsets
--         bit 31~0 - AT_tile_col_offsets[63:32] (Read/Write)
-- 0x09c : reserved
-- 0x0a0 : Data signal of AT_row_idx_tiled
--         bit 31~0 - AT_row_idx_tiled[31:0] (Read/Write)
-- 0x0a4 : Data signal of AT_row_idx_tiled
--         bit 31~0 - AT_row_idx_tiled[63:32] (Read/Write)
-- 0x0a8 : reserved
-- 0x0ac : Data signal of AT_col_ptr_tiled
--         bit 31~0 - AT_col_ptr_tiled[31:0] (Read/Write)
-- 0x0b0 : Data signal of AT_col_ptr_tiled
--         bit 31~0 - AT_col_ptr_tiled[63:32] (Read/Write)
-- 0x0b4 : reserved
-- 0x0b8 : Data signal of AT_values_tiled
--         bit 31~0 - AT_values_tiled[31:0] (Read/Write)
-- 0x0bc : Data signal of AT_values_tiled
--         bit 31~0 - AT_values_tiled[63:32] (Read/Write)
-- 0x0c0 : reserved
-- 0x0c4 : Data signal of P_tile_nnz_counts
--         bit 31~0 - P_tile_nnz_counts[31:0] (Read/Write)
-- 0x0c8 : Data signal of P_tile_nnz_counts
--         bit 31~0 - P_tile_nnz_counts[63:32] (Read/Write)
-- 0x0cc : reserved
-- 0x0d0 : Data signal of P_tile_nnz_offsets
--         bit 31~0 - P_tile_nnz_offsets[31:0] (Read/Write)
-- 0x0d4 : Data signal of P_tile_nnz_offsets
--         bit 31~0 - P_tile_nnz_offsets[63:32] (Read/Write)
-- 0x0d8 : reserved
-- 0x0dc : Data signal of P_tile_col_offsets
--         bit 31~0 - P_tile_col_offsets[31:0] (Read/Write)
-- 0x0e0 : Data signal of P_tile_col_offsets
--         bit 31~0 - P_tile_col_offsets[63:32] (Read/Write)
-- 0x0e4 : reserved
-- 0x0e8 : Data signal of P_row_idx_tiled
--         bit 31~0 - P_row_idx_tiled[31:0] (Read/Write)
-- 0x0ec : Data signal of P_row_idx_tiled
--         bit 31~0 - P_row_idx_tiled[63:32] (Read/Write)
-- 0x0f0 : reserved
-- 0x0f4 : Data signal of P_col_ptr_tiled
--         bit 31~0 - P_col_ptr_tiled[31:0] (Read/Write)
-- 0x0f8 : Data signal of P_col_ptr_tiled
--         bit 31~0 - P_col_ptr_tiled[63:32] (Read/Write)
-- 0x0fc : reserved
-- 0x100 : Data signal of P_values_tiled
--         bit 31~0 - P_values_tiled[31:0] (Read/Write)
-- 0x104 : Data signal of P_values_tiled
--         bit 31~0 - P_values_tiled[63:32] (Read/Write)
-- 0x108 : reserved
-- 0x10c : Data signal of P_diag
--         bit 31~0 - P_diag[31:0] (Read/Write)
-- 0x110 : Data signal of P_diag
--         bit 31~0 - P_diag[63:32] (Read/Write)
-- 0x114 : reserved
-- 0x118 : Data signal of l_in
--         bit 31~0 - l_in[31:0] (Read/Write)
-- 0x11c : Data signal of l_in
--         bit 31~0 - l_in[63:32] (Read/Write)
-- 0x120 : reserved
-- 0x124 : Data signal of u_in
--         bit 31~0 - u_in[31:0] (Read/Write)
-- 0x128 : Data signal of u_in
--         bit 31~0 - u_in[63:32] (Read/Write)
-- 0x12c : reserved
-- 0x130 : Data signal of q_in
--         bit 31~0 - q_in[31:0] (Read/Write)
-- 0x134 : Data signal of q_in
--         bit 31~0 - q_in[63:32] (Read/Write)
-- 0x138 : reserved
-- 0x13c : Data signal of rho_in
--         bit 31~0 - rho_in[31:0] (Read/Write)
-- 0x140 : Data signal of rho_in
--         bit 31~0 - rho_in[63:32] (Read/Write)
-- 0x144 : reserved
-- 0x148 : Data signal of x_out
--         bit 31~0 - x_out[31:0] (Read/Write)
-- 0x14c : Data signal of x_out
--         bit 31~0 - x_out[63:32] (Read/Write)
-- 0x150 : reserved
-- 0x154 : Data signal of y_out
--         bit 31~0 - y_out[31:0] (Read/Write)
-- 0x158 : Data signal of y_out
--         bit 31~0 - y_out[63:32] (Read/Write)
-- 0x15c : reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of admm_control_r_s_axi is
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_A_ROW_IDX_DATA_0           : INTEGER := 16#010#;
    constant ADDR_A_ROW_IDX_DATA_1           : INTEGER := 16#014#;
    constant ADDR_A_ROW_IDX_CTRL             : INTEGER := 16#018#;
    constant ADDR_A_COL_PTR_DATA_0           : INTEGER := 16#01c#;
    constant ADDR_A_COL_PTR_DATA_1           : INTEGER := 16#020#;
    constant ADDR_A_COL_PTR_CTRL             : INTEGER := 16#024#;
    constant ADDR_A_VALUES_DATA_0            : INTEGER := 16#028#;
    constant ADDR_A_VALUES_DATA_1            : INTEGER := 16#02c#;
    constant ADDR_A_VALUES_CTRL              : INTEGER := 16#030#;
    constant ADDR_A_TILE_NNZ_COUNTS_DATA_0   : INTEGER := 16#034#;
    constant ADDR_A_TILE_NNZ_COUNTS_DATA_1   : INTEGER := 16#038#;
    constant ADDR_A_TILE_NNZ_COUNTS_CTRL     : INTEGER := 16#03c#;
    constant ADDR_A_TILE_NNZ_OFFSETS_DATA_0  : INTEGER := 16#040#;
    constant ADDR_A_TILE_NNZ_OFFSETS_DATA_1  : INTEGER := 16#044#;
    constant ADDR_A_TILE_NNZ_OFFSETS_CTRL    : INTEGER := 16#048#;
    constant ADDR_A_TILE_COL_OFFSETS_DATA_0  : INTEGER := 16#04c#;
    constant ADDR_A_TILE_COL_OFFSETS_DATA_1  : INTEGER := 16#050#;
    constant ADDR_A_TILE_COL_OFFSETS_CTRL    : INTEGER := 16#054#;
    constant ADDR_A_ROW_IDX_TILED_DATA_0     : INTEGER := 16#058#;
    constant ADDR_A_ROW_IDX_TILED_DATA_1     : INTEGER := 16#05c#;
    constant ADDR_A_ROW_IDX_TILED_CTRL       : INTEGER := 16#060#;
    constant ADDR_A_COL_PTR_TILED_DATA_0     : INTEGER := 16#064#;
    constant ADDR_A_COL_PTR_TILED_DATA_1     : INTEGER := 16#068#;
    constant ADDR_A_COL_PTR_TILED_CTRL       : INTEGER := 16#06c#;
    constant ADDR_A_VALUES_TILED_DATA_0      : INTEGER := 16#070#;
    constant ADDR_A_VALUES_TILED_DATA_1      : INTEGER := 16#074#;
    constant ADDR_A_VALUES_TILED_CTRL        : INTEGER := 16#078#;
    constant ADDR_AT_TILE_NNZ_COUNTS_DATA_0  : INTEGER := 16#07c#;
    constant ADDR_AT_TILE_NNZ_COUNTS_DATA_1  : INTEGER := 16#080#;
    constant ADDR_AT_TILE_NNZ_COUNTS_CTRL    : INTEGER := 16#084#;
    constant ADDR_AT_TILE_NNZ_OFFSETS_DATA_0 : INTEGER := 16#088#;
    constant ADDR_AT_TILE_NNZ_OFFSETS_DATA_1 : INTEGER := 16#08c#;
    constant ADDR_AT_TILE_NNZ_OFFSETS_CTRL   : INTEGER := 16#090#;
    constant ADDR_AT_TILE_COL_OFFSETS_DATA_0 : INTEGER := 16#094#;
    constant ADDR_AT_TILE_COL_OFFSETS_DATA_1 : INTEGER := 16#098#;
    constant ADDR_AT_TILE_COL_OFFSETS_CTRL   : INTEGER := 16#09c#;
    constant ADDR_AT_ROW_IDX_TILED_DATA_0    : INTEGER := 16#0a0#;
    constant ADDR_AT_ROW_IDX_TILED_DATA_1    : INTEGER := 16#0a4#;
    constant ADDR_AT_ROW_IDX_TILED_CTRL      : INTEGER := 16#0a8#;
    constant ADDR_AT_COL_PTR_TILED_DATA_0    : INTEGER := 16#0ac#;
    constant ADDR_AT_COL_PTR_TILED_DATA_1    : INTEGER := 16#0b0#;
    constant ADDR_AT_COL_PTR_TILED_CTRL      : INTEGER := 16#0b4#;
    constant ADDR_AT_VALUES_TILED_DATA_0     : INTEGER := 16#0b8#;
    constant ADDR_AT_VALUES_TILED_DATA_1     : INTEGER := 16#0bc#;
    constant ADDR_AT_VALUES_TILED_CTRL       : INTEGER := 16#0c0#;
    constant ADDR_P_TILE_NNZ_COUNTS_DATA_0   : INTEGER := 16#0c4#;
    constant ADDR_P_TILE_NNZ_COUNTS_DATA_1   : INTEGER := 16#0c8#;
    constant ADDR_P_TILE_NNZ_COUNTS_CTRL     : INTEGER := 16#0cc#;
    constant ADDR_P_TILE_NNZ_OFFSETS_DATA_0  : INTEGER := 16#0d0#;
    constant ADDR_P_TILE_NNZ_OFFSETS_DATA_1  : INTEGER := 16#0d4#;
    constant ADDR_P_TILE_NNZ_OFFSETS_CTRL    : INTEGER := 16#0d8#;
    constant ADDR_P_TILE_COL_OFFSETS_DATA_0  : INTEGER := 16#0dc#;
    constant ADDR_P_TILE_COL_OFFSETS_DATA_1  : INTEGER := 16#0e0#;
    constant ADDR_P_TILE_COL_OFFSETS_CTRL    : INTEGER := 16#0e4#;
    constant ADDR_P_ROW_IDX_TILED_DATA_0     : INTEGER := 16#0e8#;
    constant ADDR_P_ROW_IDX_TILED_DATA_1     : INTEGER := 16#0ec#;
    constant ADDR_P_ROW_IDX_TILED_CTRL       : INTEGER := 16#0f0#;
    constant ADDR_P_COL_PTR_TILED_DATA_0     : INTEGER := 16#0f4#;
    constant ADDR_P_COL_PTR_TILED_DATA_1     : INTEGER := 16#0f8#;
    constant ADDR_P_COL_PTR_TILED_CTRL       : INTEGER := 16#0fc#;
    constant ADDR_P_VALUES_TILED_DATA_0      : INTEGER := 16#100#;
    constant ADDR_P_VALUES_TILED_DATA_1      : INTEGER := 16#104#;
    constant ADDR_P_VALUES_TILED_CTRL        : INTEGER := 16#108#;
    constant ADDR_P_DIAG_DATA_0              : INTEGER := 16#10c#;
    constant ADDR_P_DIAG_DATA_1              : INTEGER := 16#110#;
    constant ADDR_P_DIAG_CTRL                : INTEGER := 16#114#;
    constant ADDR_L_IN_DATA_0                : INTEGER := 16#118#;
    constant ADDR_L_IN_DATA_1                : INTEGER := 16#11c#;
    constant ADDR_L_IN_CTRL                  : INTEGER := 16#120#;
    constant ADDR_U_IN_DATA_0                : INTEGER := 16#124#;
    constant ADDR_U_IN_DATA_1                : INTEGER := 16#128#;
    constant ADDR_U_IN_CTRL                  : INTEGER := 16#12c#;
    constant ADDR_Q_IN_DATA_0                : INTEGER := 16#130#;
    constant ADDR_Q_IN_DATA_1                : INTEGER := 16#134#;
    constant ADDR_Q_IN_CTRL                  : INTEGER := 16#138#;
    constant ADDR_RHO_IN_DATA_0              : INTEGER := 16#13c#;
    constant ADDR_RHO_IN_DATA_1              : INTEGER := 16#140#;
    constant ADDR_RHO_IN_CTRL                : INTEGER := 16#144#;
    constant ADDR_X_OUT_DATA_0               : INTEGER := 16#148#;
    constant ADDR_X_OUT_DATA_1               : INTEGER := 16#14c#;
    constant ADDR_X_OUT_CTRL                 : INTEGER := 16#150#;
    constant ADDR_Y_OUT_DATA_0               : INTEGER := 16#154#;
    constant ADDR_Y_OUT_DATA_1               : INTEGER := 16#158#;
    constant ADDR_Y_OUT_CTRL                 : INTEGER := 16#15c#;
    constant ADDR_BITS         : INTEGER := 9;

    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    -- internal registers
    signal int_A_row_idx       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_A_col_ptr       : UNSIGNED(63 downto 0) := (others => '0');
    signal int_A_values        : UNSIGNED(63 downto 0) := (others => '0');
    signal int_A_tile_nnz_counts : UNSIGNED(63 downto 0) := (others => '0');
    signal int_A_tile_nnz_offsets : UNSIGNED(63 downto 0) := (others => '0');
    signal int_A_tile_col_offsets : UNSIGNED(63 downto 0) := (others => '0');
    signal int_A_row_idx_tiled : UNSIGNED(63 downto 0) := (others => '0');
    signal int_A_col_ptr_tiled : UNSIGNED(63 downto 0) := (others => '0');
    signal int_A_values_tiled  : UNSIGNED(63 downto 0) := (others => '0');
    signal int_AT_tile_nnz_counts : UNSIGNED(63 downto 0) := (others => '0');
    signal int_AT_tile_nnz_offsets : UNSIGNED(63 downto 0) := (others => '0');
    signal int_AT_tile_col_offsets : UNSIGNED(63 downto 0) := (others => '0');
    signal int_AT_row_idx_tiled : UNSIGNED(63 downto 0) := (others => '0');
    signal int_AT_col_ptr_tiled : UNSIGNED(63 downto 0) := (others => '0');
    signal int_AT_values_tiled : UNSIGNED(63 downto 0) := (others => '0');
    signal int_P_tile_nnz_counts : UNSIGNED(63 downto 0) := (others => '0');
    signal int_P_tile_nnz_offsets : UNSIGNED(63 downto 0) := (others => '0');
    signal int_P_tile_col_offsets : UNSIGNED(63 downto 0) := (others => '0');
    signal int_P_row_idx_tiled : UNSIGNED(63 downto 0) := (others => '0');
    signal int_P_col_ptr_tiled : UNSIGNED(63 downto 0) := (others => '0');
    signal int_P_values_tiled  : UNSIGNED(63 downto 0) := (others => '0');
    signal int_P_diag          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_l_in            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_u_in            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_q_in            : UNSIGNED(63 downto 0) := (others => '0');
    signal int_rho_in          : UNSIGNED(63 downto 0) := (others => '0');
    signal int_x_out           : UNSIGNED(63 downto 0) := (others => '0');
    signal int_y_out           : UNSIGNED(63 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BRESP     <=  "00";  -- OKAY
    BVALID    <=  '1' when wstate = wrresp else '0';
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 2) & (1 downto 0 => '0'));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_A_ROW_IDX_DATA_0 =>
                        rdata_data <= RESIZE(int_A_row_idx(31 downto 0), 32);
                    when ADDR_A_ROW_IDX_DATA_1 =>
                        rdata_data <= RESIZE(int_A_row_idx(63 downto 32), 32);
                    when ADDR_A_COL_PTR_DATA_0 =>
                        rdata_data <= RESIZE(int_A_col_ptr(31 downto 0), 32);
                    when ADDR_A_COL_PTR_DATA_1 =>
                        rdata_data <= RESIZE(int_A_col_ptr(63 downto 32), 32);
                    when ADDR_A_VALUES_DATA_0 =>
                        rdata_data <= RESIZE(int_A_values(31 downto 0), 32);
                    when ADDR_A_VALUES_DATA_1 =>
                        rdata_data <= RESIZE(int_A_values(63 downto 32), 32);
                    when ADDR_A_TILE_NNZ_COUNTS_DATA_0 =>
                        rdata_data <= RESIZE(int_A_tile_nnz_counts(31 downto 0), 32);
                    when ADDR_A_TILE_NNZ_COUNTS_DATA_1 =>
                        rdata_data <= RESIZE(int_A_tile_nnz_counts(63 downto 32), 32);
                    when ADDR_A_TILE_NNZ_OFFSETS_DATA_0 =>
                        rdata_data <= RESIZE(int_A_tile_nnz_offsets(31 downto 0), 32);
                    when ADDR_A_TILE_NNZ_OFFSETS_DATA_1 =>
                        rdata_data <= RESIZE(int_A_tile_nnz_offsets(63 downto 32), 32);
                    when ADDR_A_TILE_COL_OFFSETS_DATA_0 =>
                        rdata_data <= RESIZE(int_A_tile_col_offsets(31 downto 0), 32);
                    when ADDR_A_TILE_COL_OFFSETS_DATA_1 =>
                        rdata_data <= RESIZE(int_A_tile_col_offsets(63 downto 32), 32);
                    when ADDR_A_ROW_IDX_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_A_row_idx_tiled(31 downto 0), 32);
                    when ADDR_A_ROW_IDX_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_A_row_idx_tiled(63 downto 32), 32);
                    when ADDR_A_COL_PTR_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_A_col_ptr_tiled(31 downto 0), 32);
                    when ADDR_A_COL_PTR_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_A_col_ptr_tiled(63 downto 32), 32);
                    when ADDR_A_VALUES_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_A_values_tiled(31 downto 0), 32);
                    when ADDR_A_VALUES_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_A_values_tiled(63 downto 32), 32);
                    when ADDR_AT_TILE_NNZ_COUNTS_DATA_0 =>
                        rdata_data <= RESIZE(int_AT_tile_nnz_counts(31 downto 0), 32);
                    when ADDR_AT_TILE_NNZ_COUNTS_DATA_1 =>
                        rdata_data <= RESIZE(int_AT_tile_nnz_counts(63 downto 32), 32);
                    when ADDR_AT_TILE_NNZ_OFFSETS_DATA_0 =>
                        rdata_data <= RESIZE(int_AT_tile_nnz_offsets(31 downto 0), 32);
                    when ADDR_AT_TILE_NNZ_OFFSETS_DATA_1 =>
                        rdata_data <= RESIZE(int_AT_tile_nnz_offsets(63 downto 32), 32);
                    when ADDR_AT_TILE_COL_OFFSETS_DATA_0 =>
                        rdata_data <= RESIZE(int_AT_tile_col_offsets(31 downto 0), 32);
                    when ADDR_AT_TILE_COL_OFFSETS_DATA_1 =>
                        rdata_data <= RESIZE(int_AT_tile_col_offsets(63 downto 32), 32);
                    when ADDR_AT_ROW_IDX_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_AT_row_idx_tiled(31 downto 0), 32);
                    when ADDR_AT_ROW_IDX_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_AT_row_idx_tiled(63 downto 32), 32);
                    when ADDR_AT_COL_PTR_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_AT_col_ptr_tiled(31 downto 0), 32);
                    when ADDR_AT_COL_PTR_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_AT_col_ptr_tiled(63 downto 32), 32);
                    when ADDR_AT_VALUES_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_AT_values_tiled(31 downto 0), 32);
                    when ADDR_AT_VALUES_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_AT_values_tiled(63 downto 32), 32);
                    when ADDR_P_TILE_NNZ_COUNTS_DATA_0 =>
                        rdata_data <= RESIZE(int_P_tile_nnz_counts(31 downto 0), 32);
                    when ADDR_P_TILE_NNZ_COUNTS_DATA_1 =>
                        rdata_data <= RESIZE(int_P_tile_nnz_counts(63 downto 32), 32);
                    when ADDR_P_TILE_NNZ_OFFSETS_DATA_0 =>
                        rdata_data <= RESIZE(int_P_tile_nnz_offsets(31 downto 0), 32);
                    when ADDR_P_TILE_NNZ_OFFSETS_DATA_1 =>
                        rdata_data <= RESIZE(int_P_tile_nnz_offsets(63 downto 32), 32);
                    when ADDR_P_TILE_COL_OFFSETS_DATA_0 =>
                        rdata_data <= RESIZE(int_P_tile_col_offsets(31 downto 0), 32);
                    when ADDR_P_TILE_COL_OFFSETS_DATA_1 =>
                        rdata_data <= RESIZE(int_P_tile_col_offsets(63 downto 32), 32);
                    when ADDR_P_ROW_IDX_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_P_row_idx_tiled(31 downto 0), 32);
                    when ADDR_P_ROW_IDX_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_P_row_idx_tiled(63 downto 32), 32);
                    when ADDR_P_COL_PTR_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_P_col_ptr_tiled(31 downto 0), 32);
                    when ADDR_P_COL_PTR_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_P_col_ptr_tiled(63 downto 32), 32);
                    when ADDR_P_VALUES_TILED_DATA_0 =>
                        rdata_data <= RESIZE(int_P_values_tiled(31 downto 0), 32);
                    when ADDR_P_VALUES_TILED_DATA_1 =>
                        rdata_data <= RESIZE(int_P_values_tiled(63 downto 32), 32);
                    when ADDR_P_DIAG_DATA_0 =>
                        rdata_data <= RESIZE(int_P_diag(31 downto 0), 32);
                    when ADDR_P_DIAG_DATA_1 =>
                        rdata_data <= RESIZE(int_P_diag(63 downto 32), 32);
                    when ADDR_L_IN_DATA_0 =>
                        rdata_data <= RESIZE(int_l_in(31 downto 0), 32);
                    when ADDR_L_IN_DATA_1 =>
                        rdata_data <= RESIZE(int_l_in(63 downto 32), 32);
                    when ADDR_U_IN_DATA_0 =>
                        rdata_data <= RESIZE(int_u_in(31 downto 0), 32);
                    when ADDR_U_IN_DATA_1 =>
                        rdata_data <= RESIZE(int_u_in(63 downto 32), 32);
                    when ADDR_Q_IN_DATA_0 =>
                        rdata_data <= RESIZE(int_q_in(31 downto 0), 32);
                    when ADDR_Q_IN_DATA_1 =>
                        rdata_data <= RESIZE(int_q_in(63 downto 32), 32);
                    when ADDR_RHO_IN_DATA_0 =>
                        rdata_data <= RESIZE(int_rho_in(31 downto 0), 32);
                    when ADDR_RHO_IN_DATA_1 =>
                        rdata_data <= RESIZE(int_rho_in(63 downto 32), 32);
                    when ADDR_X_OUT_DATA_0 =>
                        rdata_data <= RESIZE(int_x_out(31 downto 0), 32);
                    when ADDR_X_OUT_DATA_1 =>
                        rdata_data <= RESIZE(int_x_out(63 downto 32), 32);
                    when ADDR_Y_OUT_DATA_0 =>
                        rdata_data <= RESIZE(int_y_out(31 downto 0), 32);
                    when ADDR_Y_OUT_DATA_1 =>
                        rdata_data <= RESIZE(int_y_out(63 downto 32), 32);
                    when others =>
                        NULL;
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    A_row_idx            <= STD_LOGIC_VECTOR(int_A_row_idx);
    A_col_ptr            <= STD_LOGIC_VECTOR(int_A_col_ptr);
    A_values             <= STD_LOGIC_VECTOR(int_A_values);
    A_tile_nnz_counts    <= STD_LOGIC_VECTOR(int_A_tile_nnz_counts);
    A_tile_nnz_offsets   <= STD_LOGIC_VECTOR(int_A_tile_nnz_offsets);
    A_tile_col_offsets   <= STD_LOGIC_VECTOR(int_A_tile_col_offsets);
    A_row_idx_tiled      <= STD_LOGIC_VECTOR(int_A_row_idx_tiled);
    A_col_ptr_tiled      <= STD_LOGIC_VECTOR(int_A_col_ptr_tiled);
    A_values_tiled       <= STD_LOGIC_VECTOR(int_A_values_tiled);
    AT_tile_nnz_counts   <= STD_LOGIC_VECTOR(int_AT_tile_nnz_counts);
    AT_tile_nnz_offsets  <= STD_LOGIC_VECTOR(int_AT_tile_nnz_offsets);
    AT_tile_col_offsets  <= STD_LOGIC_VECTOR(int_AT_tile_col_offsets);
    AT_row_idx_tiled     <= STD_LOGIC_VECTOR(int_AT_row_idx_tiled);
    AT_col_ptr_tiled     <= STD_LOGIC_VECTOR(int_AT_col_ptr_tiled);
    AT_values_tiled      <= STD_LOGIC_VECTOR(int_AT_values_tiled);
    P_tile_nnz_counts    <= STD_LOGIC_VECTOR(int_P_tile_nnz_counts);
    P_tile_nnz_offsets   <= STD_LOGIC_VECTOR(int_P_tile_nnz_offsets);
    P_tile_col_offsets   <= STD_LOGIC_VECTOR(int_P_tile_col_offsets);
    P_row_idx_tiled      <= STD_LOGIC_VECTOR(int_P_row_idx_tiled);
    P_col_ptr_tiled      <= STD_LOGIC_VECTOR(int_P_col_ptr_tiled);
    P_values_tiled       <= STD_LOGIC_VECTOR(int_P_values_tiled);
    P_diag               <= STD_LOGIC_VECTOR(int_P_diag);
    l_in                 <= STD_LOGIC_VECTOR(int_l_in);
    u_in                 <= STD_LOGIC_VECTOR(int_u_in);
    q_in                 <= STD_LOGIC_VECTOR(int_q_in);
    rho_in               <= STD_LOGIC_VECTOR(int_rho_in);
    x_out                <= STD_LOGIC_VECTOR(int_x_out);
    y_out                <= STD_LOGIC_VECTOR(int_y_out);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_row_idx(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_ROW_IDX_DATA_0) then
                    int_A_row_idx(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_row_idx(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_row_idx(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_ROW_IDX_DATA_1) then
                    int_A_row_idx(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_row_idx(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_col_ptr(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_COL_PTR_DATA_0) then
                    int_A_col_ptr(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_col_ptr(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_col_ptr(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_COL_PTR_DATA_1) then
                    int_A_col_ptr(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_col_ptr(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_values(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_VALUES_DATA_0) then
                    int_A_values(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_values(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_values(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_VALUES_DATA_1) then
                    int_A_values(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_values(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_tile_nnz_counts(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_TILE_NNZ_COUNTS_DATA_0) then
                    int_A_tile_nnz_counts(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_tile_nnz_counts(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_tile_nnz_counts(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_TILE_NNZ_COUNTS_DATA_1) then
                    int_A_tile_nnz_counts(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_tile_nnz_counts(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_tile_nnz_offsets(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_TILE_NNZ_OFFSETS_DATA_0) then
                    int_A_tile_nnz_offsets(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_tile_nnz_offsets(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_tile_nnz_offsets(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_TILE_NNZ_OFFSETS_DATA_1) then
                    int_A_tile_nnz_offsets(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_tile_nnz_offsets(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_tile_col_offsets(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_TILE_COL_OFFSETS_DATA_0) then
                    int_A_tile_col_offsets(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_tile_col_offsets(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_tile_col_offsets(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_TILE_COL_OFFSETS_DATA_1) then
                    int_A_tile_col_offsets(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_tile_col_offsets(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_row_idx_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_ROW_IDX_TILED_DATA_0) then
                    int_A_row_idx_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_row_idx_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_row_idx_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_ROW_IDX_TILED_DATA_1) then
                    int_A_row_idx_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_row_idx_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_col_ptr_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_COL_PTR_TILED_DATA_0) then
                    int_A_col_ptr_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_col_ptr_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_col_ptr_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_COL_PTR_TILED_DATA_1) then
                    int_A_col_ptr_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_col_ptr_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_values_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_VALUES_TILED_DATA_0) then
                    int_A_values_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_values_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_A_values_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_A_VALUES_TILED_DATA_1) then
                    int_A_values_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_A_values_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_tile_nnz_counts(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_TILE_NNZ_COUNTS_DATA_0) then
                    int_AT_tile_nnz_counts(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_tile_nnz_counts(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_tile_nnz_counts(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_TILE_NNZ_COUNTS_DATA_1) then
                    int_AT_tile_nnz_counts(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_tile_nnz_counts(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_tile_nnz_offsets(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_TILE_NNZ_OFFSETS_DATA_0) then
                    int_AT_tile_nnz_offsets(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_tile_nnz_offsets(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_tile_nnz_offsets(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_TILE_NNZ_OFFSETS_DATA_1) then
                    int_AT_tile_nnz_offsets(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_tile_nnz_offsets(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_tile_col_offsets(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_TILE_COL_OFFSETS_DATA_0) then
                    int_AT_tile_col_offsets(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_tile_col_offsets(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_tile_col_offsets(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_TILE_COL_OFFSETS_DATA_1) then
                    int_AT_tile_col_offsets(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_tile_col_offsets(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_row_idx_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_ROW_IDX_TILED_DATA_0) then
                    int_AT_row_idx_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_row_idx_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_row_idx_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_ROW_IDX_TILED_DATA_1) then
                    int_AT_row_idx_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_row_idx_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_col_ptr_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_COL_PTR_TILED_DATA_0) then
                    int_AT_col_ptr_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_col_ptr_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_col_ptr_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_COL_PTR_TILED_DATA_1) then
                    int_AT_col_ptr_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_col_ptr_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_values_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_VALUES_TILED_DATA_0) then
                    int_AT_values_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_values_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_AT_values_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AT_VALUES_TILED_DATA_1) then
                    int_AT_values_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_AT_values_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_tile_nnz_counts(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_TILE_NNZ_COUNTS_DATA_0) then
                    int_P_tile_nnz_counts(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_tile_nnz_counts(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_tile_nnz_counts(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_TILE_NNZ_COUNTS_DATA_1) then
                    int_P_tile_nnz_counts(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_tile_nnz_counts(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_tile_nnz_offsets(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_TILE_NNZ_OFFSETS_DATA_0) then
                    int_P_tile_nnz_offsets(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_tile_nnz_offsets(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_tile_nnz_offsets(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_TILE_NNZ_OFFSETS_DATA_1) then
                    int_P_tile_nnz_offsets(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_tile_nnz_offsets(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_tile_col_offsets(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_TILE_COL_OFFSETS_DATA_0) then
                    int_P_tile_col_offsets(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_tile_col_offsets(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_tile_col_offsets(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_TILE_COL_OFFSETS_DATA_1) then
                    int_P_tile_col_offsets(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_tile_col_offsets(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_row_idx_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_ROW_IDX_TILED_DATA_0) then
                    int_P_row_idx_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_row_idx_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_row_idx_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_ROW_IDX_TILED_DATA_1) then
                    int_P_row_idx_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_row_idx_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_col_ptr_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_COL_PTR_TILED_DATA_0) then
                    int_P_col_ptr_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_col_ptr_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_col_ptr_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_COL_PTR_TILED_DATA_1) then
                    int_P_col_ptr_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_col_ptr_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_values_tiled(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_VALUES_TILED_DATA_0) then
                    int_P_values_tiled(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_values_tiled(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_values_tiled(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_VALUES_TILED_DATA_1) then
                    int_P_values_tiled(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_values_tiled(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_diag(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_DIAG_DATA_0) then
                    int_P_diag(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_diag(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_P_diag(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_P_DIAG_DATA_1) then
                    int_P_diag(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_P_diag(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_l_in(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_L_IN_DATA_0) then
                    int_l_in(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_l_in(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_l_in(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_L_IN_DATA_1) then
                    int_l_in(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_l_in(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_u_in(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_U_IN_DATA_0) then
                    int_u_in(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_u_in(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_u_in(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_U_IN_DATA_1) then
                    int_u_in(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_u_in(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_q_in(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_Q_IN_DATA_0) then
                    int_q_in(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_q_in(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_q_in(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_Q_IN_DATA_1) then
                    int_q_in(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_q_in(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_rho_in(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_RHO_IN_DATA_0) then
                    int_rho_in(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_rho_in(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_rho_in(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_RHO_IN_DATA_1) then
                    int_rho_in(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_rho_in(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_x_out(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_OUT_DATA_0) then
                    int_x_out(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_x_out(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_x_out(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_X_OUT_DATA_1) then
                    int_x_out(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_x_out(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_y_out(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_Y_OUT_DATA_0) then
                    int_y_out(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_y_out(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_y_out(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_Y_OUT_DATA_1) then
                    int_y_out(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_y_out(63 downto 32));
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
