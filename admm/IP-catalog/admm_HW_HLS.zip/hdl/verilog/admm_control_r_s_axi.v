// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module admm_control_r_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 9,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire [63:0]                   A_row_idx,
    output wire [63:0]                   A_col_ptr,
    output wire [63:0]                   A_values,
    output wire [63:0]                   A_tile_nnz_counts,
    output wire [63:0]                   A_tile_nnz_offsets,
    output wire [63:0]                   A_tile_col_offsets,
    output wire [63:0]                   A_row_idx_tiled,
    output wire [63:0]                   A_col_ptr_tiled,
    output wire [63:0]                   A_values_tiled,
    output wire [63:0]                   AT_tile_nnz_counts,
    output wire [63:0]                   AT_tile_nnz_offsets,
    output wire [63:0]                   AT_tile_col_offsets,
    output wire [63:0]                   AT_row_idx_tiled,
    output wire [63:0]                   AT_col_ptr_tiled,
    output wire [63:0]                   AT_values_tiled,
    output wire [63:0]                   P_tile_nnz_counts,
    output wire [63:0]                   P_tile_nnz_offsets,
    output wire [63:0]                   P_tile_col_offsets,
    output wire [63:0]                   P_row_idx_tiled,
    output wire [63:0]                   P_col_ptr_tiled,
    output wire [63:0]                   P_values_tiled,
    output wire [63:0]                   P_diag,
    output wire [63:0]                   l_in,
    output wire [63:0]                   u_in,
    output wire [63:0]                   q_in,
    output wire [63:0]                   rho_in,
    output wire [63:0]                   x_out,
    output wire [63:0]                   y_out
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_none
//
// 0x000 : reserved
// 0x004 : reserved
// 0x008 : reserved
// 0x00c : reserved
// 0x010 : Data signal of A_row_idx
//         bit 31~0 - A_row_idx[31:0] (Read/Write)
// 0x014 : Data signal of A_row_idx
//         bit 31~0 - A_row_idx[63:32] (Read/Write)
// 0x018 : reserved
// 0x01c : Data signal of A_col_ptr
//         bit 31~0 - A_col_ptr[31:0] (Read/Write)
// 0x020 : Data signal of A_col_ptr
//         bit 31~0 - A_col_ptr[63:32] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of A_values
//         bit 31~0 - A_values[31:0] (Read/Write)
// 0x02c : Data signal of A_values
//         bit 31~0 - A_values[63:32] (Read/Write)
// 0x030 : reserved
// 0x034 : Data signal of A_tile_nnz_counts
//         bit 31~0 - A_tile_nnz_counts[31:0] (Read/Write)
// 0x038 : Data signal of A_tile_nnz_counts
//         bit 31~0 - A_tile_nnz_counts[63:32] (Read/Write)
// 0x03c : reserved
// 0x040 : Data signal of A_tile_nnz_offsets
//         bit 31~0 - A_tile_nnz_offsets[31:0] (Read/Write)
// 0x044 : Data signal of A_tile_nnz_offsets
//         bit 31~0 - A_tile_nnz_offsets[63:32] (Read/Write)
// 0x048 : reserved
// 0x04c : Data signal of A_tile_col_offsets
//         bit 31~0 - A_tile_col_offsets[31:0] (Read/Write)
// 0x050 : Data signal of A_tile_col_offsets
//         bit 31~0 - A_tile_col_offsets[63:32] (Read/Write)
// 0x054 : reserved
// 0x058 : Data signal of A_row_idx_tiled
//         bit 31~0 - A_row_idx_tiled[31:0] (Read/Write)
// 0x05c : Data signal of A_row_idx_tiled
//         bit 31~0 - A_row_idx_tiled[63:32] (Read/Write)
// 0x060 : reserved
// 0x064 : Data signal of A_col_ptr_tiled
//         bit 31~0 - A_col_ptr_tiled[31:0] (Read/Write)
// 0x068 : Data signal of A_col_ptr_tiled
//         bit 31~0 - A_col_ptr_tiled[63:32] (Read/Write)
// 0x06c : reserved
// 0x070 : Data signal of A_values_tiled
//         bit 31~0 - A_values_tiled[31:0] (Read/Write)
// 0x074 : Data signal of A_values_tiled
//         bit 31~0 - A_values_tiled[63:32] (Read/Write)
// 0x078 : reserved
// 0x07c : Data signal of AT_tile_nnz_counts
//         bit 31~0 - AT_tile_nnz_counts[31:0] (Read/Write)
// 0x080 : Data signal of AT_tile_nnz_counts
//         bit 31~0 - AT_tile_nnz_counts[63:32] (Read/Write)
// 0x084 : reserved
// 0x088 : Data signal of AT_tile_nnz_offsets
//         bit 31~0 - AT_tile_nnz_offsets[31:0] (Read/Write)
// 0x08c : Data signal of AT_tile_nnz_offsets
//         bit 31~0 - AT_tile_nnz_offsets[63:32] (Read/Write)
// 0x090 : reserved
// 0x094 : Data signal of AT_tile_col_offsets
//         bit 31~0 - AT_tile_col_offsets[31:0] (Read/Write)
// 0x098 : Data signal of AT_tile_col_offsets
//         bit 31~0 - AT_tile_col_offsets[63:32] (Read/Write)
// 0x09c : reserved
// 0x0a0 : Data signal of AT_row_idx_tiled
//         bit 31~0 - AT_row_idx_tiled[31:0] (Read/Write)
// 0x0a4 : Data signal of AT_row_idx_tiled
//         bit 31~0 - AT_row_idx_tiled[63:32] (Read/Write)
// 0x0a8 : reserved
// 0x0ac : Data signal of AT_col_ptr_tiled
//         bit 31~0 - AT_col_ptr_tiled[31:0] (Read/Write)
// 0x0b0 : Data signal of AT_col_ptr_tiled
//         bit 31~0 - AT_col_ptr_tiled[63:32] (Read/Write)
// 0x0b4 : reserved
// 0x0b8 : Data signal of AT_values_tiled
//         bit 31~0 - AT_values_tiled[31:0] (Read/Write)
// 0x0bc : Data signal of AT_values_tiled
//         bit 31~0 - AT_values_tiled[63:32] (Read/Write)
// 0x0c0 : reserved
// 0x0c4 : Data signal of P_tile_nnz_counts
//         bit 31~0 - P_tile_nnz_counts[31:0] (Read/Write)
// 0x0c8 : Data signal of P_tile_nnz_counts
//         bit 31~0 - P_tile_nnz_counts[63:32] (Read/Write)
// 0x0cc : reserved
// 0x0d0 : Data signal of P_tile_nnz_offsets
//         bit 31~0 - P_tile_nnz_offsets[31:0] (Read/Write)
// 0x0d4 : Data signal of P_tile_nnz_offsets
//         bit 31~0 - P_tile_nnz_offsets[63:32] (Read/Write)
// 0x0d8 : reserved
// 0x0dc : Data signal of P_tile_col_offsets
//         bit 31~0 - P_tile_col_offsets[31:0] (Read/Write)
// 0x0e0 : Data signal of P_tile_col_offsets
//         bit 31~0 - P_tile_col_offsets[63:32] (Read/Write)
// 0x0e4 : reserved
// 0x0e8 : Data signal of P_row_idx_tiled
//         bit 31~0 - P_row_idx_tiled[31:0] (Read/Write)
// 0x0ec : Data signal of P_row_idx_tiled
//         bit 31~0 - P_row_idx_tiled[63:32] (Read/Write)
// 0x0f0 : reserved
// 0x0f4 : Data signal of P_col_ptr_tiled
//         bit 31~0 - P_col_ptr_tiled[31:0] (Read/Write)
// 0x0f8 : Data signal of P_col_ptr_tiled
//         bit 31~0 - P_col_ptr_tiled[63:32] (Read/Write)
// 0x0fc : reserved
// 0x100 : Data signal of P_values_tiled
//         bit 31~0 - P_values_tiled[31:0] (Read/Write)
// 0x104 : Data signal of P_values_tiled
//         bit 31~0 - P_values_tiled[63:32] (Read/Write)
// 0x108 : reserved
// 0x10c : Data signal of P_diag
//         bit 31~0 - P_diag[31:0] (Read/Write)
// 0x110 : Data signal of P_diag
//         bit 31~0 - P_diag[63:32] (Read/Write)
// 0x114 : reserved
// 0x118 : Data signal of l_in
//         bit 31~0 - l_in[31:0] (Read/Write)
// 0x11c : Data signal of l_in
//         bit 31~0 - l_in[63:32] (Read/Write)
// 0x120 : reserved
// 0x124 : Data signal of u_in
//         bit 31~0 - u_in[31:0] (Read/Write)
// 0x128 : Data signal of u_in
//         bit 31~0 - u_in[63:32] (Read/Write)
// 0x12c : reserved
// 0x130 : Data signal of q_in
//         bit 31~0 - q_in[31:0] (Read/Write)
// 0x134 : Data signal of q_in
//         bit 31~0 - q_in[63:32] (Read/Write)
// 0x138 : reserved
// 0x13c : Data signal of rho_in
//         bit 31~0 - rho_in[31:0] (Read/Write)
// 0x140 : Data signal of rho_in
//         bit 31~0 - rho_in[63:32] (Read/Write)
// 0x144 : reserved
// 0x148 : Data signal of x_out
//         bit 31~0 - x_out[31:0] (Read/Write)
// 0x14c : Data signal of x_out
//         bit 31~0 - x_out[63:32] (Read/Write)
// 0x150 : reserved
// 0x154 : Data signal of y_out
//         bit 31~0 - y_out[31:0] (Read/Write)
// 0x158 : Data signal of y_out
//         bit 31~0 - y_out[63:32] (Read/Write)
// 0x15c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_A_ROW_IDX_DATA_0           = 9'h010,
    ADDR_A_ROW_IDX_DATA_1           = 9'h014,
    ADDR_A_ROW_IDX_CTRL             = 9'h018,
    ADDR_A_COL_PTR_DATA_0           = 9'h01c,
    ADDR_A_COL_PTR_DATA_1           = 9'h020,
    ADDR_A_COL_PTR_CTRL             = 9'h024,
    ADDR_A_VALUES_DATA_0            = 9'h028,
    ADDR_A_VALUES_DATA_1            = 9'h02c,
    ADDR_A_VALUES_CTRL              = 9'h030,
    ADDR_A_TILE_NNZ_COUNTS_DATA_0   = 9'h034,
    ADDR_A_TILE_NNZ_COUNTS_DATA_1   = 9'h038,
    ADDR_A_TILE_NNZ_COUNTS_CTRL     = 9'h03c,
    ADDR_A_TILE_NNZ_OFFSETS_DATA_0  = 9'h040,
    ADDR_A_TILE_NNZ_OFFSETS_DATA_1  = 9'h044,
    ADDR_A_TILE_NNZ_OFFSETS_CTRL    = 9'h048,
    ADDR_A_TILE_COL_OFFSETS_DATA_0  = 9'h04c,
    ADDR_A_TILE_COL_OFFSETS_DATA_1  = 9'h050,
    ADDR_A_TILE_COL_OFFSETS_CTRL    = 9'h054,
    ADDR_A_ROW_IDX_TILED_DATA_0     = 9'h058,
    ADDR_A_ROW_IDX_TILED_DATA_1     = 9'h05c,
    ADDR_A_ROW_IDX_TILED_CTRL       = 9'h060,
    ADDR_A_COL_PTR_TILED_DATA_0     = 9'h064,
    ADDR_A_COL_PTR_TILED_DATA_1     = 9'h068,
    ADDR_A_COL_PTR_TILED_CTRL       = 9'h06c,
    ADDR_A_VALUES_TILED_DATA_0      = 9'h070,
    ADDR_A_VALUES_TILED_DATA_1      = 9'h074,
    ADDR_A_VALUES_TILED_CTRL        = 9'h078,
    ADDR_AT_TILE_NNZ_COUNTS_DATA_0  = 9'h07c,
    ADDR_AT_TILE_NNZ_COUNTS_DATA_1  = 9'h080,
    ADDR_AT_TILE_NNZ_COUNTS_CTRL    = 9'h084,
    ADDR_AT_TILE_NNZ_OFFSETS_DATA_0 = 9'h088,
    ADDR_AT_TILE_NNZ_OFFSETS_DATA_1 = 9'h08c,
    ADDR_AT_TILE_NNZ_OFFSETS_CTRL   = 9'h090,
    ADDR_AT_TILE_COL_OFFSETS_DATA_0 = 9'h094,
    ADDR_AT_TILE_COL_OFFSETS_DATA_1 = 9'h098,
    ADDR_AT_TILE_COL_OFFSETS_CTRL   = 9'h09c,
    ADDR_AT_ROW_IDX_TILED_DATA_0    = 9'h0a0,
    ADDR_AT_ROW_IDX_TILED_DATA_1    = 9'h0a4,
    ADDR_AT_ROW_IDX_TILED_CTRL      = 9'h0a8,
    ADDR_AT_COL_PTR_TILED_DATA_0    = 9'h0ac,
    ADDR_AT_COL_PTR_TILED_DATA_1    = 9'h0b0,
    ADDR_AT_COL_PTR_TILED_CTRL      = 9'h0b4,
    ADDR_AT_VALUES_TILED_DATA_0     = 9'h0b8,
    ADDR_AT_VALUES_TILED_DATA_1     = 9'h0bc,
    ADDR_AT_VALUES_TILED_CTRL       = 9'h0c0,
    ADDR_P_TILE_NNZ_COUNTS_DATA_0   = 9'h0c4,
    ADDR_P_TILE_NNZ_COUNTS_DATA_1   = 9'h0c8,
    ADDR_P_TILE_NNZ_COUNTS_CTRL     = 9'h0cc,
    ADDR_P_TILE_NNZ_OFFSETS_DATA_0  = 9'h0d0,
    ADDR_P_TILE_NNZ_OFFSETS_DATA_1  = 9'h0d4,
    ADDR_P_TILE_NNZ_OFFSETS_CTRL    = 9'h0d8,
    ADDR_P_TILE_COL_OFFSETS_DATA_0  = 9'h0dc,
    ADDR_P_TILE_COL_OFFSETS_DATA_1  = 9'h0e0,
    ADDR_P_TILE_COL_OFFSETS_CTRL    = 9'h0e4,
    ADDR_P_ROW_IDX_TILED_DATA_0     = 9'h0e8,
    ADDR_P_ROW_IDX_TILED_DATA_1     = 9'h0ec,
    ADDR_P_ROW_IDX_TILED_CTRL       = 9'h0f0,
    ADDR_P_COL_PTR_TILED_DATA_0     = 9'h0f4,
    ADDR_P_COL_PTR_TILED_DATA_1     = 9'h0f8,
    ADDR_P_COL_PTR_TILED_CTRL       = 9'h0fc,
    ADDR_P_VALUES_TILED_DATA_0      = 9'h100,
    ADDR_P_VALUES_TILED_DATA_1      = 9'h104,
    ADDR_P_VALUES_TILED_CTRL        = 9'h108,
    ADDR_P_DIAG_DATA_0              = 9'h10c,
    ADDR_P_DIAG_DATA_1              = 9'h110,
    ADDR_P_DIAG_CTRL                = 9'h114,
    ADDR_L_IN_DATA_0                = 9'h118,
    ADDR_L_IN_DATA_1                = 9'h11c,
    ADDR_L_IN_CTRL                  = 9'h120,
    ADDR_U_IN_DATA_0                = 9'h124,
    ADDR_U_IN_DATA_1                = 9'h128,
    ADDR_U_IN_CTRL                  = 9'h12c,
    ADDR_Q_IN_DATA_0                = 9'h130,
    ADDR_Q_IN_DATA_1                = 9'h134,
    ADDR_Q_IN_CTRL                  = 9'h138,
    ADDR_RHO_IN_DATA_0              = 9'h13c,
    ADDR_RHO_IN_DATA_1              = 9'h140,
    ADDR_RHO_IN_CTRL                = 9'h144,
    ADDR_X_OUT_DATA_0               = 9'h148,
    ADDR_X_OUT_DATA_1               = 9'h14c,
    ADDR_X_OUT_CTRL                 = 9'h150,
    ADDR_Y_OUT_DATA_0               = 9'h154,
    ADDR_Y_OUT_DATA_1               = 9'h158,
    ADDR_Y_OUT_CTRL                 = 9'h15c,
    WRIDLE                          = 2'd0,
    WRDATA                          = 2'd1,
    WRRESP                          = 2'd2,
    WRRESET                         = 2'd3,
    RDIDLE                          = 2'd0,
    RDDATA                          = 2'd1,
    RDRESET                         = 2'd2,
    ADDR_BITS                = 9;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg  [63:0]                   int_A_row_idx = 'b0;
    reg  [63:0]                   int_A_col_ptr = 'b0;
    reg  [63:0]                   int_A_values = 'b0;
    reg  [63:0]                   int_A_tile_nnz_counts = 'b0;
    reg  [63:0]                   int_A_tile_nnz_offsets = 'b0;
    reg  [63:0]                   int_A_tile_col_offsets = 'b0;
    reg  [63:0]                   int_A_row_idx_tiled = 'b0;
    reg  [63:0]                   int_A_col_ptr_tiled = 'b0;
    reg  [63:0]                   int_A_values_tiled = 'b0;
    reg  [63:0]                   int_AT_tile_nnz_counts = 'b0;
    reg  [63:0]                   int_AT_tile_nnz_offsets = 'b0;
    reg  [63:0]                   int_AT_tile_col_offsets = 'b0;
    reg  [63:0]                   int_AT_row_idx_tiled = 'b0;
    reg  [63:0]                   int_AT_col_ptr_tiled = 'b0;
    reg  [63:0]                   int_AT_values_tiled = 'b0;
    reg  [63:0]                   int_P_tile_nnz_counts = 'b0;
    reg  [63:0]                   int_P_tile_nnz_offsets = 'b0;
    reg  [63:0]                   int_P_tile_col_offsets = 'b0;
    reg  [63:0]                   int_P_row_idx_tiled = 'b0;
    reg  [63:0]                   int_P_col_ptr_tiled = 'b0;
    reg  [63:0]                   int_P_values_tiled = 'b0;
    reg  [63:0]                   int_P_diag = 'b0;
    reg  [63:0]                   int_l_in = 'b0;
    reg  [63:0]                   int_u_in = 'b0;
    reg  [63:0]                   int_q_in = 'b0;
    reg  [63:0]                   int_rho_in = 'b0;
    reg  [63:0]                   int_x_out = 'b0;
    reg  [63:0]                   int_y_out = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= {AWADDR[ADDR_BITS-1:2], {2{1'b0}}};
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_A_ROW_IDX_DATA_0: begin
                    rdata <= int_A_row_idx[31:0];
                end
                ADDR_A_ROW_IDX_DATA_1: begin
                    rdata <= int_A_row_idx[63:32];
                end
                ADDR_A_COL_PTR_DATA_0: begin
                    rdata <= int_A_col_ptr[31:0];
                end
                ADDR_A_COL_PTR_DATA_1: begin
                    rdata <= int_A_col_ptr[63:32];
                end
                ADDR_A_VALUES_DATA_0: begin
                    rdata <= int_A_values[31:0];
                end
                ADDR_A_VALUES_DATA_1: begin
                    rdata <= int_A_values[63:32];
                end
                ADDR_A_TILE_NNZ_COUNTS_DATA_0: begin
                    rdata <= int_A_tile_nnz_counts[31:0];
                end
                ADDR_A_TILE_NNZ_COUNTS_DATA_1: begin
                    rdata <= int_A_tile_nnz_counts[63:32];
                end
                ADDR_A_TILE_NNZ_OFFSETS_DATA_0: begin
                    rdata <= int_A_tile_nnz_offsets[31:0];
                end
                ADDR_A_TILE_NNZ_OFFSETS_DATA_1: begin
                    rdata <= int_A_tile_nnz_offsets[63:32];
                end
                ADDR_A_TILE_COL_OFFSETS_DATA_0: begin
                    rdata <= int_A_tile_col_offsets[31:0];
                end
                ADDR_A_TILE_COL_OFFSETS_DATA_1: begin
                    rdata <= int_A_tile_col_offsets[63:32];
                end
                ADDR_A_ROW_IDX_TILED_DATA_0: begin
                    rdata <= int_A_row_idx_tiled[31:0];
                end
                ADDR_A_ROW_IDX_TILED_DATA_1: begin
                    rdata <= int_A_row_idx_tiled[63:32];
                end
                ADDR_A_COL_PTR_TILED_DATA_0: begin
                    rdata <= int_A_col_ptr_tiled[31:0];
                end
                ADDR_A_COL_PTR_TILED_DATA_1: begin
                    rdata <= int_A_col_ptr_tiled[63:32];
                end
                ADDR_A_VALUES_TILED_DATA_0: begin
                    rdata <= int_A_values_tiled[31:0];
                end
                ADDR_A_VALUES_TILED_DATA_1: begin
                    rdata <= int_A_values_tiled[63:32];
                end
                ADDR_AT_TILE_NNZ_COUNTS_DATA_0: begin
                    rdata <= int_AT_tile_nnz_counts[31:0];
                end
                ADDR_AT_TILE_NNZ_COUNTS_DATA_1: begin
                    rdata <= int_AT_tile_nnz_counts[63:32];
                end
                ADDR_AT_TILE_NNZ_OFFSETS_DATA_0: begin
                    rdata <= int_AT_tile_nnz_offsets[31:0];
                end
                ADDR_AT_TILE_NNZ_OFFSETS_DATA_1: begin
                    rdata <= int_AT_tile_nnz_offsets[63:32];
                end
                ADDR_AT_TILE_COL_OFFSETS_DATA_0: begin
                    rdata <= int_AT_tile_col_offsets[31:0];
                end
                ADDR_AT_TILE_COL_OFFSETS_DATA_1: begin
                    rdata <= int_AT_tile_col_offsets[63:32];
                end
                ADDR_AT_ROW_IDX_TILED_DATA_0: begin
                    rdata <= int_AT_row_idx_tiled[31:0];
                end
                ADDR_AT_ROW_IDX_TILED_DATA_1: begin
                    rdata <= int_AT_row_idx_tiled[63:32];
                end
                ADDR_AT_COL_PTR_TILED_DATA_0: begin
                    rdata <= int_AT_col_ptr_tiled[31:0];
                end
                ADDR_AT_COL_PTR_TILED_DATA_1: begin
                    rdata <= int_AT_col_ptr_tiled[63:32];
                end
                ADDR_AT_VALUES_TILED_DATA_0: begin
                    rdata <= int_AT_values_tiled[31:0];
                end
                ADDR_AT_VALUES_TILED_DATA_1: begin
                    rdata <= int_AT_values_tiled[63:32];
                end
                ADDR_P_TILE_NNZ_COUNTS_DATA_0: begin
                    rdata <= int_P_tile_nnz_counts[31:0];
                end
                ADDR_P_TILE_NNZ_COUNTS_DATA_1: begin
                    rdata <= int_P_tile_nnz_counts[63:32];
                end
                ADDR_P_TILE_NNZ_OFFSETS_DATA_0: begin
                    rdata <= int_P_tile_nnz_offsets[31:0];
                end
                ADDR_P_TILE_NNZ_OFFSETS_DATA_1: begin
                    rdata <= int_P_tile_nnz_offsets[63:32];
                end
                ADDR_P_TILE_COL_OFFSETS_DATA_0: begin
                    rdata <= int_P_tile_col_offsets[31:0];
                end
                ADDR_P_TILE_COL_OFFSETS_DATA_1: begin
                    rdata <= int_P_tile_col_offsets[63:32];
                end
                ADDR_P_ROW_IDX_TILED_DATA_0: begin
                    rdata <= int_P_row_idx_tiled[31:0];
                end
                ADDR_P_ROW_IDX_TILED_DATA_1: begin
                    rdata <= int_P_row_idx_tiled[63:32];
                end
                ADDR_P_COL_PTR_TILED_DATA_0: begin
                    rdata <= int_P_col_ptr_tiled[31:0];
                end
                ADDR_P_COL_PTR_TILED_DATA_1: begin
                    rdata <= int_P_col_ptr_tiled[63:32];
                end
                ADDR_P_VALUES_TILED_DATA_0: begin
                    rdata <= int_P_values_tiled[31:0];
                end
                ADDR_P_VALUES_TILED_DATA_1: begin
                    rdata <= int_P_values_tiled[63:32];
                end
                ADDR_P_DIAG_DATA_0: begin
                    rdata <= int_P_diag[31:0];
                end
                ADDR_P_DIAG_DATA_1: begin
                    rdata <= int_P_diag[63:32];
                end
                ADDR_L_IN_DATA_0: begin
                    rdata <= int_l_in[31:0];
                end
                ADDR_L_IN_DATA_1: begin
                    rdata <= int_l_in[63:32];
                end
                ADDR_U_IN_DATA_0: begin
                    rdata <= int_u_in[31:0];
                end
                ADDR_U_IN_DATA_1: begin
                    rdata <= int_u_in[63:32];
                end
                ADDR_Q_IN_DATA_0: begin
                    rdata <= int_q_in[31:0];
                end
                ADDR_Q_IN_DATA_1: begin
                    rdata <= int_q_in[63:32];
                end
                ADDR_RHO_IN_DATA_0: begin
                    rdata <= int_rho_in[31:0];
                end
                ADDR_RHO_IN_DATA_1: begin
                    rdata <= int_rho_in[63:32];
                end
                ADDR_X_OUT_DATA_0: begin
                    rdata <= int_x_out[31:0];
                end
                ADDR_X_OUT_DATA_1: begin
                    rdata <= int_x_out[63:32];
                end
                ADDR_Y_OUT_DATA_0: begin
                    rdata <= int_y_out[31:0];
                end
                ADDR_Y_OUT_DATA_1: begin
                    rdata <= int_y_out[63:32];
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign A_row_idx           = int_A_row_idx;
assign A_col_ptr           = int_A_col_ptr;
assign A_values            = int_A_values;
assign A_tile_nnz_counts   = int_A_tile_nnz_counts;
assign A_tile_nnz_offsets  = int_A_tile_nnz_offsets;
assign A_tile_col_offsets  = int_A_tile_col_offsets;
assign A_row_idx_tiled     = int_A_row_idx_tiled;
assign A_col_ptr_tiled     = int_A_col_ptr_tiled;
assign A_values_tiled      = int_A_values_tiled;
assign AT_tile_nnz_counts  = int_AT_tile_nnz_counts;
assign AT_tile_nnz_offsets = int_AT_tile_nnz_offsets;
assign AT_tile_col_offsets = int_AT_tile_col_offsets;
assign AT_row_idx_tiled    = int_AT_row_idx_tiled;
assign AT_col_ptr_tiled    = int_AT_col_ptr_tiled;
assign AT_values_tiled     = int_AT_values_tiled;
assign P_tile_nnz_counts   = int_P_tile_nnz_counts;
assign P_tile_nnz_offsets  = int_P_tile_nnz_offsets;
assign P_tile_col_offsets  = int_P_tile_col_offsets;
assign P_row_idx_tiled     = int_P_row_idx_tiled;
assign P_col_ptr_tiled     = int_P_col_ptr_tiled;
assign P_values_tiled      = int_P_values_tiled;
assign P_diag              = int_P_diag;
assign l_in                = int_l_in;
assign u_in                = int_u_in;
assign q_in                = int_q_in;
assign rho_in              = int_rho_in;
assign x_out               = int_x_out;
assign y_out               = int_y_out;
// int_A_row_idx[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_row_idx[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_ROW_IDX_DATA_0)
            int_A_row_idx[31:0] <= (WDATA[31:0] & wmask) | (int_A_row_idx[31:0] & ~wmask);
    end
end

// int_A_row_idx[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_row_idx[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_ROW_IDX_DATA_1)
            int_A_row_idx[63:32] <= (WDATA[31:0] & wmask) | (int_A_row_idx[63:32] & ~wmask);
    end
end

// int_A_col_ptr[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_col_ptr[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_COL_PTR_DATA_0)
            int_A_col_ptr[31:0] <= (WDATA[31:0] & wmask) | (int_A_col_ptr[31:0] & ~wmask);
    end
end

// int_A_col_ptr[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_col_ptr[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_COL_PTR_DATA_1)
            int_A_col_ptr[63:32] <= (WDATA[31:0] & wmask) | (int_A_col_ptr[63:32] & ~wmask);
    end
end

// int_A_values[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_values[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_VALUES_DATA_0)
            int_A_values[31:0] <= (WDATA[31:0] & wmask) | (int_A_values[31:0] & ~wmask);
    end
end

// int_A_values[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_values[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_VALUES_DATA_1)
            int_A_values[63:32] <= (WDATA[31:0] & wmask) | (int_A_values[63:32] & ~wmask);
    end
end

// int_A_tile_nnz_counts[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_tile_nnz_counts[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_TILE_NNZ_COUNTS_DATA_0)
            int_A_tile_nnz_counts[31:0] <= (WDATA[31:0] & wmask) | (int_A_tile_nnz_counts[31:0] & ~wmask);
    end
end

// int_A_tile_nnz_counts[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_tile_nnz_counts[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_TILE_NNZ_COUNTS_DATA_1)
            int_A_tile_nnz_counts[63:32] <= (WDATA[31:0] & wmask) | (int_A_tile_nnz_counts[63:32] & ~wmask);
    end
end

// int_A_tile_nnz_offsets[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_tile_nnz_offsets[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_TILE_NNZ_OFFSETS_DATA_0)
            int_A_tile_nnz_offsets[31:0] <= (WDATA[31:0] & wmask) | (int_A_tile_nnz_offsets[31:0] & ~wmask);
    end
end

// int_A_tile_nnz_offsets[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_tile_nnz_offsets[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_TILE_NNZ_OFFSETS_DATA_1)
            int_A_tile_nnz_offsets[63:32] <= (WDATA[31:0] & wmask) | (int_A_tile_nnz_offsets[63:32] & ~wmask);
    end
end

// int_A_tile_col_offsets[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_tile_col_offsets[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_TILE_COL_OFFSETS_DATA_0)
            int_A_tile_col_offsets[31:0] <= (WDATA[31:0] & wmask) | (int_A_tile_col_offsets[31:0] & ~wmask);
    end
end

// int_A_tile_col_offsets[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_tile_col_offsets[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_TILE_COL_OFFSETS_DATA_1)
            int_A_tile_col_offsets[63:32] <= (WDATA[31:0] & wmask) | (int_A_tile_col_offsets[63:32] & ~wmask);
    end
end

// int_A_row_idx_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_row_idx_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_ROW_IDX_TILED_DATA_0)
            int_A_row_idx_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_A_row_idx_tiled[31:0] & ~wmask);
    end
end

// int_A_row_idx_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_row_idx_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_ROW_IDX_TILED_DATA_1)
            int_A_row_idx_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_A_row_idx_tiled[63:32] & ~wmask);
    end
end

// int_A_col_ptr_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_col_ptr_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_COL_PTR_TILED_DATA_0)
            int_A_col_ptr_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_A_col_ptr_tiled[31:0] & ~wmask);
    end
end

// int_A_col_ptr_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_col_ptr_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_COL_PTR_TILED_DATA_1)
            int_A_col_ptr_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_A_col_ptr_tiled[63:32] & ~wmask);
    end
end

// int_A_values_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_values_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_VALUES_TILED_DATA_0)
            int_A_values_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_A_values_tiled[31:0] & ~wmask);
    end
end

// int_A_values_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_values_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_VALUES_TILED_DATA_1)
            int_A_values_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_A_values_tiled[63:32] & ~wmask);
    end
end

// int_AT_tile_nnz_counts[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_tile_nnz_counts[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_TILE_NNZ_COUNTS_DATA_0)
            int_AT_tile_nnz_counts[31:0] <= (WDATA[31:0] & wmask) | (int_AT_tile_nnz_counts[31:0] & ~wmask);
    end
end

// int_AT_tile_nnz_counts[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_tile_nnz_counts[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_TILE_NNZ_COUNTS_DATA_1)
            int_AT_tile_nnz_counts[63:32] <= (WDATA[31:0] & wmask) | (int_AT_tile_nnz_counts[63:32] & ~wmask);
    end
end

// int_AT_tile_nnz_offsets[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_tile_nnz_offsets[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_TILE_NNZ_OFFSETS_DATA_0)
            int_AT_tile_nnz_offsets[31:0] <= (WDATA[31:0] & wmask) | (int_AT_tile_nnz_offsets[31:0] & ~wmask);
    end
end

// int_AT_tile_nnz_offsets[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_tile_nnz_offsets[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_TILE_NNZ_OFFSETS_DATA_1)
            int_AT_tile_nnz_offsets[63:32] <= (WDATA[31:0] & wmask) | (int_AT_tile_nnz_offsets[63:32] & ~wmask);
    end
end

// int_AT_tile_col_offsets[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_tile_col_offsets[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_TILE_COL_OFFSETS_DATA_0)
            int_AT_tile_col_offsets[31:0] <= (WDATA[31:0] & wmask) | (int_AT_tile_col_offsets[31:0] & ~wmask);
    end
end

// int_AT_tile_col_offsets[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_tile_col_offsets[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_TILE_COL_OFFSETS_DATA_1)
            int_AT_tile_col_offsets[63:32] <= (WDATA[31:0] & wmask) | (int_AT_tile_col_offsets[63:32] & ~wmask);
    end
end

// int_AT_row_idx_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_row_idx_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_ROW_IDX_TILED_DATA_0)
            int_AT_row_idx_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_AT_row_idx_tiled[31:0] & ~wmask);
    end
end

// int_AT_row_idx_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_row_idx_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_ROW_IDX_TILED_DATA_1)
            int_AT_row_idx_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_AT_row_idx_tiled[63:32] & ~wmask);
    end
end

// int_AT_col_ptr_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_col_ptr_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_COL_PTR_TILED_DATA_0)
            int_AT_col_ptr_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_AT_col_ptr_tiled[31:0] & ~wmask);
    end
end

// int_AT_col_ptr_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_col_ptr_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_COL_PTR_TILED_DATA_1)
            int_AT_col_ptr_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_AT_col_ptr_tiled[63:32] & ~wmask);
    end
end

// int_AT_values_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_values_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_VALUES_TILED_DATA_0)
            int_AT_values_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_AT_values_tiled[31:0] & ~wmask);
    end
end

// int_AT_values_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_values_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_VALUES_TILED_DATA_1)
            int_AT_values_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_AT_values_tiled[63:32] & ~wmask);
    end
end

// int_P_tile_nnz_counts[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_tile_nnz_counts[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_TILE_NNZ_COUNTS_DATA_0)
            int_P_tile_nnz_counts[31:0] <= (WDATA[31:0] & wmask) | (int_P_tile_nnz_counts[31:0] & ~wmask);
    end
end

// int_P_tile_nnz_counts[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_tile_nnz_counts[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_TILE_NNZ_COUNTS_DATA_1)
            int_P_tile_nnz_counts[63:32] <= (WDATA[31:0] & wmask) | (int_P_tile_nnz_counts[63:32] & ~wmask);
    end
end

// int_P_tile_nnz_offsets[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_tile_nnz_offsets[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_TILE_NNZ_OFFSETS_DATA_0)
            int_P_tile_nnz_offsets[31:0] <= (WDATA[31:0] & wmask) | (int_P_tile_nnz_offsets[31:0] & ~wmask);
    end
end

// int_P_tile_nnz_offsets[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_tile_nnz_offsets[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_TILE_NNZ_OFFSETS_DATA_1)
            int_P_tile_nnz_offsets[63:32] <= (WDATA[31:0] & wmask) | (int_P_tile_nnz_offsets[63:32] & ~wmask);
    end
end

// int_P_tile_col_offsets[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_tile_col_offsets[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_TILE_COL_OFFSETS_DATA_0)
            int_P_tile_col_offsets[31:0] <= (WDATA[31:0] & wmask) | (int_P_tile_col_offsets[31:0] & ~wmask);
    end
end

// int_P_tile_col_offsets[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_tile_col_offsets[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_TILE_COL_OFFSETS_DATA_1)
            int_P_tile_col_offsets[63:32] <= (WDATA[31:0] & wmask) | (int_P_tile_col_offsets[63:32] & ~wmask);
    end
end

// int_P_row_idx_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_row_idx_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_ROW_IDX_TILED_DATA_0)
            int_P_row_idx_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_P_row_idx_tiled[31:0] & ~wmask);
    end
end

// int_P_row_idx_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_row_idx_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_ROW_IDX_TILED_DATA_1)
            int_P_row_idx_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_P_row_idx_tiled[63:32] & ~wmask);
    end
end

// int_P_col_ptr_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_col_ptr_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_COL_PTR_TILED_DATA_0)
            int_P_col_ptr_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_P_col_ptr_tiled[31:0] & ~wmask);
    end
end

// int_P_col_ptr_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_col_ptr_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_COL_PTR_TILED_DATA_1)
            int_P_col_ptr_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_P_col_ptr_tiled[63:32] & ~wmask);
    end
end

// int_P_values_tiled[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_values_tiled[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_VALUES_TILED_DATA_0)
            int_P_values_tiled[31:0] <= (WDATA[31:0] & wmask) | (int_P_values_tiled[31:0] & ~wmask);
    end
end

// int_P_values_tiled[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_values_tiled[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_VALUES_TILED_DATA_1)
            int_P_values_tiled[63:32] <= (WDATA[31:0] & wmask) | (int_P_values_tiled[63:32] & ~wmask);
    end
end

// int_P_diag[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_diag[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_DIAG_DATA_0)
            int_P_diag[31:0] <= (WDATA[31:0] & wmask) | (int_P_diag[31:0] & ~wmask);
    end
end

// int_P_diag[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_diag[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_DIAG_DATA_1)
            int_P_diag[63:32] <= (WDATA[31:0] & wmask) | (int_P_diag[63:32] & ~wmask);
    end
end

// int_l_in[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_l_in[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_L_IN_DATA_0)
            int_l_in[31:0] <= (WDATA[31:0] & wmask) | (int_l_in[31:0] & ~wmask);
    end
end

// int_l_in[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_l_in[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_L_IN_DATA_1)
            int_l_in[63:32] <= (WDATA[31:0] & wmask) | (int_l_in[63:32] & ~wmask);
    end
end

// int_u_in[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_in[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_IN_DATA_0)
            int_u_in[31:0] <= (WDATA[31:0] & wmask) | (int_u_in[31:0] & ~wmask);
    end
end

// int_u_in[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_u_in[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_U_IN_DATA_1)
            int_u_in[63:32] <= (WDATA[31:0] & wmask) | (int_u_in[63:32] & ~wmask);
    end
end

// int_q_in[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_q_in[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_Q_IN_DATA_0)
            int_q_in[31:0] <= (WDATA[31:0] & wmask) | (int_q_in[31:0] & ~wmask);
    end
end

// int_q_in[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_q_in[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_Q_IN_DATA_1)
            int_q_in[63:32] <= (WDATA[31:0] & wmask) | (int_q_in[63:32] & ~wmask);
    end
end

// int_rho_in[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_rho_in[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_RHO_IN_DATA_0)
            int_rho_in[31:0] <= (WDATA[31:0] & wmask) | (int_rho_in[31:0] & ~wmask);
    end
end

// int_rho_in[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_rho_in[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_RHO_IN_DATA_1)
            int_rho_in[63:32] <= (WDATA[31:0] & wmask) | (int_rho_in[63:32] & ~wmask);
    end
end

// int_x_out[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_x_out[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_X_OUT_DATA_0)
            int_x_out[31:0] <= (WDATA[31:0] & wmask) | (int_x_out[31:0] & ~wmask);
    end
end

// int_x_out[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_x_out[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_X_OUT_DATA_1)
            int_x_out[63:32] <= (WDATA[31:0] & wmask) | (int_x_out[63:32] & ~wmask);
    end
end

// int_y_out[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_y_out[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_Y_OUT_DATA_0)
            int_y_out[31:0] <= (WDATA[31:0] & wmask) | (int_y_out[31:0] & ~wmask);
    end
end

// int_y_out[63:32]
always @(posedge ACLK) begin
    if (ARESET)
        int_y_out[63:32] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_Y_OUT_DATA_1)
            int_y_out[63:32] <= (WDATA[31:0] & wmask) | (int_y_out[63:32] & ~wmask);
    end
end


//------------------------Memory logic-------------------

endmodule
