// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
`timescale 1ns/1ps
module admm_control_s_axi
#(parameter
    C_S_AXI_ADDR_WIDTH = 8,
    C_S_AXI_DATA_WIDTH = 32
)(
    input  wire                          ACLK,
    input  wire                          ARESET,
    input  wire                          ACLK_EN,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] AWADDR,
    input  wire                          AWVALID,
    output wire                          AWREADY,
    input  wire [C_S_AXI_DATA_WIDTH-1:0] WDATA,
    input  wire [C_S_AXI_DATA_WIDTH/8-1:0] WSTRB,
    input  wire                          WVALID,
    output wire                          WREADY,
    output wire [1:0]                    BRESP,
    output wire                          BVALID,
    input  wire                          BREADY,
    input  wire [C_S_AXI_ADDR_WIDTH-1:0] ARADDR,
    input  wire                          ARVALID,
    output wire                          ARREADY,
    output wire [C_S_AXI_DATA_WIDTH-1:0] RDATA,
    output wire [1:0]                    RRESP,
    output wire                          RVALID,
    input  wire                          RREADY,
    output wire                          interrupt,
    output wire [31:0]                   num_rows,
    output wire [31:0]                   num_cols,
    output wire [31:0]                   A_nnz,
    output wire [31:0]                   A_num_row_tiles,
    output wire [31:0]                   A_num_col_tiles,
    output wire [31:0]                   AT_num_row_tiles,
    output wire [31:0]                   AT_num_col_tiles,
    output wire [31:0]                   P_num_row_tiles,
    output wire [31:0]                   P_num_col_tiles,
    output wire [31:0]                   sigma,
    output wire [31:0]                   alpha,
    output wire [31:0]                   admm_max_iterations,
    output wire [31:0]                   pcg_max_iterations,
    output wire [0:0]                    adaptive_rho,
    output wire [31:0]                   eps_abs,
    output wire [31:0]                   eps_rel,
    output wire [31:0]                   pcg_tol_fraction,
    input  wire [31:0]                   admm_num_iterations_out,
    input  wire                          admm_num_iterations_out_ap_vld,
    input  wire [31:0]                   pcg_num_iterations_out,
    input  wire                          pcg_num_iterations_out_ap_vld,
    input  wire [31:0]                   r_prim_out,
    input  wire                          r_prim_out_ap_vld,
    input  wire [31:0]                   r_dual_out,
    input  wire                          r_dual_out_ap_vld,
    input  wire [31:0]                   status_out,
    input  wire                          status_out_ap_vld,
    output wire                          ap_start,
    input  wire                          ap_done,
    input  wire                          ap_ready,
    input  wire                          ap_idle
);
//------------------------Address Info-------------------
// Protocol Used: ap_ctrl_hs
//
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of num_rows
//        bit 31~0 - num_rows[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of num_cols
//        bit 31~0 - num_cols[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of A_nnz
//        bit 31~0 - A_nnz[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of A_num_row_tiles
//        bit 31~0 - A_num_row_tiles[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of A_num_col_tiles
//        bit 31~0 - A_num_col_tiles[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of AT_num_row_tiles
//        bit 31~0 - AT_num_row_tiles[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of AT_num_col_tiles
//        bit 31~0 - AT_num_col_tiles[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of P_num_row_tiles
//        bit 31~0 - P_num_row_tiles[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of P_num_col_tiles
//        bit 31~0 - P_num_col_tiles[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of sigma
//        bit 31~0 - sigma[31:0] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of alpha
//        bit 31~0 - alpha[31:0] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of admm_max_iterations
//        bit 31~0 - admm_max_iterations[31:0] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of pcg_max_iterations
//        bit 31~0 - pcg_max_iterations[31:0] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of adaptive_rho
//        bit 0  - adaptive_rho[0] (Read/Write)
//        others - reserved
// 0x7c : reserved
// 0x80 : Data signal of eps_abs
//        bit 31~0 - eps_abs[31:0] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of eps_rel
//        bit 31~0 - eps_rel[31:0] (Read/Write)
// 0x8c : reserved
// 0x90 : Data signal of pcg_tol_fraction
//        bit 31~0 - pcg_tol_fraction[31:0] (Read/Write)
// 0x94 : reserved
// 0x98 : Data signal of admm_num_iterations_out
//        bit 31~0 - admm_num_iterations_out[31:0] (Read)
// 0x9c : Control signal of admm_num_iterations_out
//        bit 0  - admm_num_iterations_out_ap_vld (Read/COR)
//        others - reserved
// 0xa8 : Data signal of pcg_num_iterations_out
//        bit 31~0 - pcg_num_iterations_out[31:0] (Read)
// 0xac : Control signal of pcg_num_iterations_out
//        bit 0  - pcg_num_iterations_out_ap_vld (Read/COR)
//        others - reserved
// 0xb8 : Data signal of r_prim_out
//        bit 31~0 - r_prim_out[31:0] (Read)
// 0xbc : Control signal of r_prim_out
//        bit 0  - r_prim_out_ap_vld (Read/COR)
//        others - reserved
// 0xc8 : Data signal of r_dual_out
//        bit 31~0 - r_dual_out[31:0] (Read)
// 0xcc : Control signal of r_dual_out
//        bit 0  - r_dual_out_ap_vld (Read/COR)
//        others - reserved
// 0xd8 : Data signal of status_out
//        bit 31~0 - status_out[31:0] (Read)
// 0xdc : Control signal of status_out
//        bit 0  - status_out_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

//------------------------Parameter----------------------
localparam
    ADDR_AP_CTRL                        = 8'h00,
    ADDR_GIE                            = 8'h04,
    ADDR_IER                            = 8'h08,
    ADDR_ISR                            = 8'h0c,
    ADDR_NUM_ROWS_DATA_0                = 8'h10,
    ADDR_NUM_ROWS_CTRL                  = 8'h14,
    ADDR_NUM_COLS_DATA_0                = 8'h18,
    ADDR_NUM_COLS_CTRL                  = 8'h1c,
    ADDR_A_NNZ_DATA_0                   = 8'h20,
    ADDR_A_NNZ_CTRL                     = 8'h24,
    ADDR_A_NUM_ROW_TILES_DATA_0         = 8'h28,
    ADDR_A_NUM_ROW_TILES_CTRL           = 8'h2c,
    ADDR_A_NUM_COL_TILES_DATA_0         = 8'h30,
    ADDR_A_NUM_COL_TILES_CTRL           = 8'h34,
    ADDR_AT_NUM_ROW_TILES_DATA_0        = 8'h38,
    ADDR_AT_NUM_ROW_TILES_CTRL          = 8'h3c,
    ADDR_AT_NUM_COL_TILES_DATA_0        = 8'h40,
    ADDR_AT_NUM_COL_TILES_CTRL          = 8'h44,
    ADDR_P_NUM_ROW_TILES_DATA_0         = 8'h48,
    ADDR_P_NUM_ROW_TILES_CTRL           = 8'h4c,
    ADDR_P_NUM_COL_TILES_DATA_0         = 8'h50,
    ADDR_P_NUM_COL_TILES_CTRL           = 8'h54,
    ADDR_SIGMA_DATA_0                   = 8'h58,
    ADDR_SIGMA_CTRL                     = 8'h5c,
    ADDR_ALPHA_DATA_0                   = 8'h60,
    ADDR_ALPHA_CTRL                     = 8'h64,
    ADDR_ADMM_MAX_ITERATIONS_DATA_0     = 8'h68,
    ADDR_ADMM_MAX_ITERATIONS_CTRL       = 8'h6c,
    ADDR_PCG_MAX_ITERATIONS_DATA_0      = 8'h70,
    ADDR_PCG_MAX_ITERATIONS_CTRL        = 8'h74,
    ADDR_ADAPTIVE_RHO_DATA_0            = 8'h78,
    ADDR_ADAPTIVE_RHO_CTRL              = 8'h7c,
    ADDR_EPS_ABS_DATA_0                 = 8'h80,
    ADDR_EPS_ABS_CTRL                   = 8'h84,
    ADDR_EPS_REL_DATA_0                 = 8'h88,
    ADDR_EPS_REL_CTRL                   = 8'h8c,
    ADDR_PCG_TOL_FRACTION_DATA_0        = 8'h90,
    ADDR_PCG_TOL_FRACTION_CTRL          = 8'h94,
    ADDR_ADMM_NUM_ITERATIONS_OUT_DATA_0 = 8'h98,
    ADDR_ADMM_NUM_ITERATIONS_OUT_CTRL   = 8'h9c,
    ADDR_PCG_NUM_ITERATIONS_OUT_DATA_0  = 8'ha8,
    ADDR_PCG_NUM_ITERATIONS_OUT_CTRL    = 8'hac,
    ADDR_R_PRIM_OUT_DATA_0              = 8'hb8,
    ADDR_R_PRIM_OUT_CTRL                = 8'hbc,
    ADDR_R_DUAL_OUT_DATA_0              = 8'hc8,
    ADDR_R_DUAL_OUT_CTRL                = 8'hcc,
    ADDR_STATUS_OUT_DATA_0              = 8'hd8,
    ADDR_STATUS_OUT_CTRL                = 8'hdc,
    WRIDLE                              = 2'd0,
    WRDATA                              = 2'd1,
    WRRESP                              = 2'd2,
    WRRESET                             = 2'd3,
    RDIDLE                              = 2'd0,
    RDDATA                              = 2'd1,
    RDRESET                             = 2'd2,
    ADDR_BITS                = 8;

//------------------------Local signal-------------------
    reg  [1:0]                    wstate = WRRESET;
    reg  [1:0]                    wnext;
    reg  [ADDR_BITS-1:0]          waddr;
    wire [C_S_AXI_DATA_WIDTH-1:0] wmask;
    wire                          aw_hs;
    wire                          w_hs;
    reg  [1:0]                    rstate = RDRESET;
    reg  [1:0]                    rnext;
    reg  [C_S_AXI_DATA_WIDTH-1:0] rdata;
    wire                          ar_hs;
    wire [ADDR_BITS-1:0]          raddr;
    // internal registers
    reg                           int_ap_idle = 1'b0;
    reg                           int_ap_ready = 1'b0;
    wire                          task_ap_ready;
    reg                           int_ap_done = 1'b0;
    wire                          task_ap_done;
    reg                           int_task_ap_done = 1'b0;
    reg                           int_ap_start = 1'b0;
    reg                           int_interrupt = 1'b0;
    reg                           int_auto_restart = 1'b0;
    reg                           auto_restart_status = 1'b0;
    wire                          auto_restart_done;
    reg                           int_gie = 1'b0;
    reg  [1:0]                    int_ier = 2'b0;
    reg  [1:0]                    int_isr = 2'b0;
    reg  [31:0]                   int_num_rows = 'b0;
    reg  [31:0]                   int_num_cols = 'b0;
    reg  [31:0]                   int_A_nnz = 'b0;
    reg  [31:0]                   int_A_num_row_tiles = 'b0;
    reg  [31:0]                   int_A_num_col_tiles = 'b0;
    reg  [31:0]                   int_AT_num_row_tiles = 'b0;
    reg  [31:0]                   int_AT_num_col_tiles = 'b0;
    reg  [31:0]                   int_P_num_row_tiles = 'b0;
    reg  [31:0]                   int_P_num_col_tiles = 'b0;
    reg  [31:0]                   int_sigma = 'b0;
    reg  [31:0]                   int_alpha = 'b0;
    reg  [31:0]                   int_admm_max_iterations = 'b0;
    reg  [31:0]                   int_pcg_max_iterations = 'b0;
    reg  [0:0]                    int_adaptive_rho = 'b0;
    reg  [31:0]                   int_eps_abs = 'b0;
    reg  [31:0]                   int_eps_rel = 'b0;
    reg  [31:0]                   int_pcg_tol_fraction = 'b0;
    reg                           int_admm_num_iterations_out_ap_vld;
    reg  [31:0]                   int_admm_num_iterations_out = 'b0;
    reg                           int_pcg_num_iterations_out_ap_vld;
    reg  [31:0]                   int_pcg_num_iterations_out = 'b0;
    reg                           int_r_prim_out_ap_vld;
    reg  [31:0]                   int_r_prim_out = 'b0;
    reg                           int_r_dual_out_ap_vld;
    reg  [31:0]                   int_r_dual_out = 'b0;
    reg                           int_status_out_ap_vld;
    reg  [31:0]                   int_status_out = 'b0;

//------------------------Instantiation------------------


//------------------------AXI write fsm------------------
assign AWREADY = (wstate == WRIDLE);
assign WREADY  = (wstate == WRDATA);
assign BRESP   = 2'b00;  // OKAY
assign BVALID  = (wstate == WRRESP);
assign wmask   = { {8{WSTRB[3]}}, {8{WSTRB[2]}}, {8{WSTRB[1]}}, {8{WSTRB[0]}} };
assign aw_hs   = AWVALID & AWREADY;
assign w_hs    = WVALID & WREADY;

// wstate
always @(posedge ACLK) begin
    if (ARESET)
        wstate <= WRRESET;
    else if (ACLK_EN)
        wstate <= wnext;
end

// wnext
always @(*) begin
    case (wstate)
        WRIDLE:
            if (AWVALID)
                wnext = WRDATA;
            else
                wnext = WRIDLE;
        WRDATA:
            if (WVALID)
                wnext = WRRESP;
            else
                wnext = WRDATA;
        WRRESP:
            if (BREADY)
                wnext = WRIDLE;
            else
                wnext = WRRESP;
        default:
            wnext = WRIDLE;
    endcase
end

// waddr
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (aw_hs)
            waddr <= {AWADDR[ADDR_BITS-1:2], {2{1'b0}}};
    end
end

//------------------------AXI read fsm-------------------
assign ARREADY = (rstate == RDIDLE);
assign RDATA   = rdata;
assign RRESP   = 2'b00;  // OKAY
assign RVALID  = (rstate == RDDATA);
assign ar_hs   = ARVALID & ARREADY;
assign raddr   = ARADDR[ADDR_BITS-1:0];

// rstate
always @(posedge ACLK) begin
    if (ARESET)
        rstate <= RDRESET;
    else if (ACLK_EN)
        rstate <= rnext;
end

// rnext
always @(*) begin
    case (rstate)
        RDIDLE:
            if (ARVALID)
                rnext = RDDATA;
            else
                rnext = RDIDLE;
        RDDATA:
            if (RREADY & RVALID)
                rnext = RDIDLE;
            else
                rnext = RDDATA;
        default:
            rnext = RDIDLE;
    endcase
end

// rdata
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (ar_hs) begin
            rdata <= 'b0;
            case (raddr)
                ADDR_AP_CTRL: begin
                    rdata[0] <= int_ap_start;
                    rdata[1] <= int_task_ap_done;
                    rdata[2] <= int_ap_idle;
                    rdata[3] <= int_ap_ready;
                    rdata[7] <= int_auto_restart;
                    rdata[9] <= int_interrupt;
                end
                ADDR_GIE: begin
                    rdata <= int_gie;
                end
                ADDR_IER: begin
                    rdata <= int_ier;
                end
                ADDR_ISR: begin
                    rdata <= int_isr;
                end
                ADDR_NUM_ROWS_DATA_0: begin
                    rdata <= int_num_rows[31:0];
                end
                ADDR_NUM_COLS_DATA_0: begin
                    rdata <= int_num_cols[31:0];
                end
                ADDR_A_NNZ_DATA_0: begin
                    rdata <= int_A_nnz[31:0];
                end
                ADDR_A_NUM_ROW_TILES_DATA_0: begin
                    rdata <= int_A_num_row_tiles[31:0];
                end
                ADDR_A_NUM_COL_TILES_DATA_0: begin
                    rdata <= int_A_num_col_tiles[31:0];
                end
                ADDR_AT_NUM_ROW_TILES_DATA_0: begin
                    rdata <= int_AT_num_row_tiles[31:0];
                end
                ADDR_AT_NUM_COL_TILES_DATA_0: begin
                    rdata <= int_AT_num_col_tiles[31:0];
                end
                ADDR_P_NUM_ROW_TILES_DATA_0: begin
                    rdata <= int_P_num_row_tiles[31:0];
                end
                ADDR_P_NUM_COL_TILES_DATA_0: begin
                    rdata <= int_P_num_col_tiles[31:0];
                end
                ADDR_SIGMA_DATA_0: begin
                    rdata <= int_sigma[31:0];
                end
                ADDR_ALPHA_DATA_0: begin
                    rdata <= int_alpha[31:0];
                end
                ADDR_ADMM_MAX_ITERATIONS_DATA_0: begin
                    rdata <= int_admm_max_iterations[31:0];
                end
                ADDR_PCG_MAX_ITERATIONS_DATA_0: begin
                    rdata <= int_pcg_max_iterations[31:0];
                end
                ADDR_ADAPTIVE_RHO_DATA_0: begin
                    rdata <= int_adaptive_rho[0:0];
                end
                ADDR_EPS_ABS_DATA_0: begin
                    rdata <= int_eps_abs[31:0];
                end
                ADDR_EPS_REL_DATA_0: begin
                    rdata <= int_eps_rel[31:0];
                end
                ADDR_PCG_TOL_FRACTION_DATA_0: begin
                    rdata <= int_pcg_tol_fraction[31:0];
                end
                ADDR_ADMM_NUM_ITERATIONS_OUT_DATA_0: begin
                    rdata <= int_admm_num_iterations_out[31:0];
                end
                ADDR_ADMM_NUM_ITERATIONS_OUT_CTRL: begin
                    rdata[0] <= int_admm_num_iterations_out_ap_vld;
                end
                ADDR_PCG_NUM_ITERATIONS_OUT_DATA_0: begin
                    rdata <= int_pcg_num_iterations_out[31:0];
                end
                ADDR_PCG_NUM_ITERATIONS_OUT_CTRL: begin
                    rdata[0] <= int_pcg_num_iterations_out_ap_vld;
                end
                ADDR_R_PRIM_OUT_DATA_0: begin
                    rdata <= int_r_prim_out[31:0];
                end
                ADDR_R_PRIM_OUT_CTRL: begin
                    rdata[0] <= int_r_prim_out_ap_vld;
                end
                ADDR_R_DUAL_OUT_DATA_0: begin
                    rdata <= int_r_dual_out[31:0];
                end
                ADDR_R_DUAL_OUT_CTRL: begin
                    rdata[0] <= int_r_dual_out_ap_vld;
                end
                ADDR_STATUS_OUT_DATA_0: begin
                    rdata <= int_status_out[31:0];
                end
                ADDR_STATUS_OUT_CTRL: begin
                    rdata[0] <= int_status_out_ap_vld;
                end
            endcase
        end
    end
end


//------------------------Register logic-----------------
assign interrupt           = int_interrupt;
assign ap_start            = int_ap_start;
assign task_ap_done        = (ap_done && !auto_restart_status) || auto_restart_done;
assign task_ap_ready       = ap_ready && !int_auto_restart;
assign auto_restart_done   = auto_restart_status && (ap_idle && !int_ap_idle);
assign num_rows            = int_num_rows;
assign num_cols            = int_num_cols;
assign A_nnz               = int_A_nnz;
assign A_num_row_tiles     = int_A_num_row_tiles;
assign A_num_col_tiles     = int_A_num_col_tiles;
assign AT_num_row_tiles    = int_AT_num_row_tiles;
assign AT_num_col_tiles    = int_AT_num_col_tiles;
assign P_num_row_tiles     = int_P_num_row_tiles;
assign P_num_col_tiles     = int_P_num_col_tiles;
assign sigma               = int_sigma;
assign alpha               = int_alpha;
assign admm_max_iterations = int_admm_max_iterations;
assign pcg_max_iterations  = int_pcg_max_iterations;
assign adaptive_rho        = int_adaptive_rho;
assign eps_abs             = int_eps_abs;
assign eps_rel             = int_eps_rel;
assign pcg_tol_fraction    = int_pcg_tol_fraction;
// int_interrupt
always @(posedge ACLK) begin
    if (ARESET)
        int_interrupt <= 1'b0;
    else if (ACLK_EN) begin
        if (int_gie && (|int_isr))
            int_interrupt <= 1'b1;
        else
            int_interrupt <= 1'b0;
    end
end

// int_ap_start
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_start <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0] && WDATA[0])
            int_ap_start <= 1'b1;
        else if (ap_ready)
            int_ap_start <= int_auto_restart; // clear on handshake/auto restart
    end
end

// int_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_done <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_done <= ap_done;
    end
end

// int_task_ap_done
always @(posedge ACLK) begin
    if (ARESET)
        int_task_ap_done <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_done)
            int_task_ap_done <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_task_ap_done <= 1'b0; // clear on read
    end
end

// int_ap_idle
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_idle <= 1'b0;
    else if (ACLK_EN) begin
            int_ap_idle <= ap_idle;
    end
end

// int_ap_ready
always @(posedge ACLK) begin
    if (ARESET)
        int_ap_ready <= 1'b0;
    else if (ACLK_EN) begin
        if (task_ap_ready)
            int_ap_ready <= 1'b1;
        else if (ar_hs && raddr == ADDR_AP_CTRL)
            int_ap_ready <= 1'b0;
    end
end

// int_auto_restart
always @(posedge ACLK) begin
    if (ARESET)
        int_auto_restart <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AP_CTRL && WSTRB[0])
            int_auto_restart <= WDATA[7];
    end
end

// auto_restart_status
always @(posedge ACLK) begin
    if (ARESET)
        auto_restart_status <= 1'b0;
    else if (ACLK_EN) begin
        if (int_auto_restart)
            auto_restart_status <= 1'b1;
        else if (ap_idle)
            auto_restart_status <= 1'b0;
    end
end

// int_gie
always @(posedge ACLK) begin
    if (ARESET)
        int_gie <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_GIE && WSTRB[0])
            int_gie <= WDATA[0];
    end
end

// int_ier
always @(posedge ACLK) begin
    if (ARESET)
        int_ier <= 1'b0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_IER && WSTRB[0])
            int_ier <= WDATA[1:0];
    end
end

// int_isr[0]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[0] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[0] & ap_done)
            int_isr[0] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[0] <= int_isr[0] ^ WDATA[0]; // toggle on write
    end
end

// int_isr[1]
always @(posedge ACLK) begin
    if (ARESET)
        int_isr[1] <= 1'b0;
    else if (ACLK_EN) begin
        if (int_ier[1] & ap_ready)
            int_isr[1] <= 1'b1;
        else if (w_hs && waddr == ADDR_ISR && WSTRB[0])
            int_isr[1] <= int_isr[1] ^ WDATA[1]; // toggle on write
    end
end

// int_num_rows[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_num_rows[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_NUM_ROWS_DATA_0)
            int_num_rows[31:0] <= (WDATA[31:0] & wmask) | (int_num_rows[31:0] & ~wmask);
    end
end

// int_num_cols[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_num_cols[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_NUM_COLS_DATA_0)
            int_num_cols[31:0] <= (WDATA[31:0] & wmask) | (int_num_cols[31:0] & ~wmask);
    end
end

// int_A_nnz[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_nnz[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_NNZ_DATA_0)
            int_A_nnz[31:0] <= (WDATA[31:0] & wmask) | (int_A_nnz[31:0] & ~wmask);
    end
end

// int_A_num_row_tiles[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_num_row_tiles[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_NUM_ROW_TILES_DATA_0)
            int_A_num_row_tiles[31:0] <= (WDATA[31:0] & wmask) | (int_A_num_row_tiles[31:0] & ~wmask);
    end
end

// int_A_num_col_tiles[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_A_num_col_tiles[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_A_NUM_COL_TILES_DATA_0)
            int_A_num_col_tiles[31:0] <= (WDATA[31:0] & wmask) | (int_A_num_col_tiles[31:0] & ~wmask);
    end
end

// int_AT_num_row_tiles[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_num_row_tiles[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_NUM_ROW_TILES_DATA_0)
            int_AT_num_row_tiles[31:0] <= (WDATA[31:0] & wmask) | (int_AT_num_row_tiles[31:0] & ~wmask);
    end
end

// int_AT_num_col_tiles[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_AT_num_col_tiles[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_AT_NUM_COL_TILES_DATA_0)
            int_AT_num_col_tiles[31:0] <= (WDATA[31:0] & wmask) | (int_AT_num_col_tiles[31:0] & ~wmask);
    end
end

// int_P_num_row_tiles[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_num_row_tiles[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_NUM_ROW_TILES_DATA_0)
            int_P_num_row_tiles[31:0] <= (WDATA[31:0] & wmask) | (int_P_num_row_tiles[31:0] & ~wmask);
    end
end

// int_P_num_col_tiles[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_P_num_col_tiles[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_P_NUM_COL_TILES_DATA_0)
            int_P_num_col_tiles[31:0] <= (WDATA[31:0] & wmask) | (int_P_num_col_tiles[31:0] & ~wmask);
    end
end

// int_sigma[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_sigma[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_SIGMA_DATA_0)
            int_sigma[31:0] <= (WDATA[31:0] & wmask) | (int_sigma[31:0] & ~wmask);
    end
end

// int_alpha[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_alpha[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_ALPHA_DATA_0)
            int_alpha[31:0] <= (WDATA[31:0] & wmask) | (int_alpha[31:0] & ~wmask);
    end
end

// int_admm_max_iterations[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_admm_max_iterations[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_ADMM_MAX_ITERATIONS_DATA_0)
            int_admm_max_iterations[31:0] <= (WDATA[31:0] & wmask) | (int_admm_max_iterations[31:0] & ~wmask);
    end
end

// int_pcg_max_iterations[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pcg_max_iterations[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PCG_MAX_ITERATIONS_DATA_0)
            int_pcg_max_iterations[31:0] <= (WDATA[31:0] & wmask) | (int_pcg_max_iterations[31:0] & ~wmask);
    end
end

// int_adaptive_rho[0:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_adaptive_rho[0:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_ADAPTIVE_RHO_DATA_0)
            int_adaptive_rho[0:0] <= (WDATA[31:0] & wmask) | (int_adaptive_rho[0:0] & ~wmask);
    end
end

// int_eps_abs[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_eps_abs[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_EPS_ABS_DATA_0)
            int_eps_abs[31:0] <= (WDATA[31:0] & wmask) | (int_eps_abs[31:0] & ~wmask);
    end
end

// int_eps_rel[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_eps_rel[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_EPS_REL_DATA_0)
            int_eps_rel[31:0] <= (WDATA[31:0] & wmask) | (int_eps_rel[31:0] & ~wmask);
    end
end

// int_pcg_tol_fraction[31:0]
always @(posedge ACLK) begin
    if (ARESET)
        int_pcg_tol_fraction[31:0] <= 0;
    else if (ACLK_EN) begin
        if (w_hs && waddr == ADDR_PCG_TOL_FRACTION_DATA_0)
            int_pcg_tol_fraction[31:0] <= (WDATA[31:0] & wmask) | (int_pcg_tol_fraction[31:0] & ~wmask);
    end
end

// int_admm_num_iterations_out
always @(posedge ACLK) begin
    if (ARESET)
        int_admm_num_iterations_out <= 0;
    else if (ACLK_EN) begin
        if (admm_num_iterations_out_ap_vld)
            int_admm_num_iterations_out <= admm_num_iterations_out;
    end
end

// int_admm_num_iterations_out_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_admm_num_iterations_out_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (admm_num_iterations_out_ap_vld)
            int_admm_num_iterations_out_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_ADMM_NUM_ITERATIONS_OUT_CTRL)
            int_admm_num_iterations_out_ap_vld <= 1'b0; // clear on read
    end
end

// int_pcg_num_iterations_out
always @(posedge ACLK) begin
    if (ARESET)
        int_pcg_num_iterations_out <= 0;
    else if (ACLK_EN) begin
        if (pcg_num_iterations_out_ap_vld)
            int_pcg_num_iterations_out <= pcg_num_iterations_out;
    end
end

// int_pcg_num_iterations_out_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_pcg_num_iterations_out_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (pcg_num_iterations_out_ap_vld)
            int_pcg_num_iterations_out_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_PCG_NUM_ITERATIONS_OUT_CTRL)
            int_pcg_num_iterations_out_ap_vld <= 1'b0; // clear on read
    end
end

// int_r_prim_out
always @(posedge ACLK) begin
    if (ARESET)
        int_r_prim_out <= 0;
    else if (ACLK_EN) begin
        if (r_prim_out_ap_vld)
            int_r_prim_out <= r_prim_out;
    end
end

// int_r_prim_out_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_r_prim_out_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (r_prim_out_ap_vld)
            int_r_prim_out_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_R_PRIM_OUT_CTRL)
            int_r_prim_out_ap_vld <= 1'b0; // clear on read
    end
end

// int_r_dual_out
always @(posedge ACLK) begin
    if (ARESET)
        int_r_dual_out <= 0;
    else if (ACLK_EN) begin
        if (r_dual_out_ap_vld)
            int_r_dual_out <= r_dual_out;
    end
end

// int_r_dual_out_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_r_dual_out_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (r_dual_out_ap_vld)
            int_r_dual_out_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_R_DUAL_OUT_CTRL)
            int_r_dual_out_ap_vld <= 1'b0; // clear on read
    end
end

// int_status_out
always @(posedge ACLK) begin
    if (ARESET)
        int_status_out <= 0;
    else if (ACLK_EN) begin
        if (status_out_ap_vld)
            int_status_out <= status_out;
    end
end

// int_status_out_ap_vld
always @(posedge ACLK) begin
    if (ARESET)
        int_status_out_ap_vld <= 1'b0;
    else if (ACLK_EN) begin
        if (status_out_ap_vld)
            int_status_out_ap_vld <= 1'b1;
        else if (ar_hs && raddr == ADDR_STATUS_OUT_CTRL)
            int_status_out_ap_vld <= 1'b0; // clear on read
    end
end

//synthesis translate_off
always @(posedge ACLK) begin
    if (ACLK_EN) begin
        if (int_gie & ~int_isr[0] & int_ier[0] & ap_done)
            $display ("// Interrupt Monitor : interrupt for ap_done detected @ \"%0t\"", $time);
        if (int_gie & ~int_isr[1] & int_ier[1] & ap_ready)
            $display ("// Interrupt Monitor : interrupt for ap_ready detected @ \"%0t\"", $time);
    end
end
//synthesis translate_on

//------------------------Memory logic-------------------

endmodule
