// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xadmm.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XAdmm_CfgInitialize(XAdmm *InstancePtr, XAdmm_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->Control_r_BaseAddress = ConfigPtr->Control_r_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XAdmm_Start(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AP_CTRL) & 0x80;
    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XAdmm_IsDone(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XAdmm_IsIdle(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XAdmm_IsReady(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XAdmm_EnableAutoRestart(XAdmm *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XAdmm_DisableAutoRestart(XAdmm *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AP_CTRL, 0);
}

void XAdmm_Set_num_rows(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_NUM_ROWS_DATA, Data);
}

u32 XAdmm_Get_num_rows(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_NUM_ROWS_DATA);
    return Data;
}

void XAdmm_Set_num_cols(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_NUM_COLS_DATA, Data);
}

u32 XAdmm_Get_num_cols(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_NUM_COLS_DATA);
    return Data;
}

void XAdmm_Set_A_nnz(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_A_NNZ_DATA, Data);
}

u32 XAdmm_Get_A_nnz(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_A_NNZ_DATA);
    return Data;
}

void XAdmm_Set_A_num_row_tiles(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_A_NUM_ROW_TILES_DATA, Data);
}

u32 XAdmm_Get_A_num_row_tiles(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_A_NUM_ROW_TILES_DATA);
    return Data;
}

void XAdmm_Set_A_num_col_tiles(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_A_NUM_COL_TILES_DATA, Data);
}

u32 XAdmm_Get_A_num_col_tiles(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_A_NUM_COL_TILES_DATA);
    return Data;
}

void XAdmm_Set_AT_num_row_tiles(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AT_NUM_ROW_TILES_DATA, Data);
}

u32 XAdmm_Get_AT_num_row_tiles(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AT_NUM_ROW_TILES_DATA);
    return Data;
}

void XAdmm_Set_AT_num_col_tiles(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AT_NUM_COL_TILES_DATA, Data);
}

u32 XAdmm_Get_AT_num_col_tiles(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_AT_NUM_COL_TILES_DATA);
    return Data;
}

void XAdmm_Set_P_num_row_tiles(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_P_NUM_ROW_TILES_DATA, Data);
}

u32 XAdmm_Get_P_num_row_tiles(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_P_NUM_ROW_TILES_DATA);
    return Data;
}

void XAdmm_Set_P_num_col_tiles(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_P_NUM_COL_TILES_DATA, Data);
}

u32 XAdmm_Get_P_num_col_tiles(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_P_NUM_COL_TILES_DATA);
    return Data;
}

void XAdmm_Set_sigma(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_SIGMA_DATA, Data);
}

u32 XAdmm_Get_sigma(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_SIGMA_DATA);
    return Data;
}

void XAdmm_Set_alpha(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ALPHA_DATA, Data);
}

u32 XAdmm_Get_alpha(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ALPHA_DATA);
    return Data;
}

void XAdmm_Set_admm_max_iterations(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ADMM_MAX_ITERATIONS_DATA, Data);
}

u32 XAdmm_Get_admm_max_iterations(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ADMM_MAX_ITERATIONS_DATA);
    return Data;
}

void XAdmm_Set_pcg_max_iterations(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_PCG_MAX_ITERATIONS_DATA, Data);
}

u32 XAdmm_Get_pcg_max_iterations(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_PCG_MAX_ITERATIONS_DATA);
    return Data;
}

void XAdmm_Set_adaptive_rho(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ADAPTIVE_RHO_DATA, Data);
}

u32 XAdmm_Get_adaptive_rho(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ADAPTIVE_RHO_DATA);
    return Data;
}

void XAdmm_Set_eps_abs(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_EPS_ABS_DATA, Data);
}

u32 XAdmm_Get_eps_abs(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_EPS_ABS_DATA);
    return Data;
}

void XAdmm_Set_eps_rel(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_EPS_REL_DATA, Data);
}

u32 XAdmm_Get_eps_rel(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_EPS_REL_DATA);
    return Data;
}

void XAdmm_Set_pcg_tol_fraction(XAdmm *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_PCG_TOL_FRACTION_DATA, Data);
}

u32 XAdmm_Get_pcg_tol_fraction(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_PCG_TOL_FRACTION_DATA);
    return Data;
}

u32 XAdmm_Get_admm_num_iterations_out(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ADMM_NUM_ITERATIONS_OUT_DATA);
    return Data;
}

u32 XAdmm_Get_admm_num_iterations_out_vld(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ADMM_NUM_ITERATIONS_OUT_CTRL);
    return Data & 0x1;
}

u32 XAdmm_Get_pcg_num_iterations_out(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_PCG_NUM_ITERATIONS_OUT_DATA);
    return Data;
}

u32 XAdmm_Get_pcg_num_iterations_out_vld(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_PCG_NUM_ITERATIONS_OUT_CTRL);
    return Data & 0x1;
}

u32 XAdmm_Get_r_prim_out(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_R_PRIM_OUT_DATA);
    return Data;
}

u32 XAdmm_Get_r_prim_out_vld(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_R_PRIM_OUT_CTRL);
    return Data & 0x1;
}

u32 XAdmm_Get_r_dual_out(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_R_DUAL_OUT_DATA);
    return Data;
}

u32 XAdmm_Get_r_dual_out_vld(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_R_DUAL_OUT_CTRL);
    return Data & 0x1;
}

u32 XAdmm_Get_status_out(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_STATUS_OUT_DATA);
    return Data;
}

u32 XAdmm_Get_status_out_vld(XAdmm *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_STATUS_OUT_CTRL);
    return Data & 0x1;
}

void XAdmm_Set_A_row_idx(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_ROW_IDX_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_ROW_IDX_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_row_idx(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_ROW_IDX_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_ROW_IDX_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_A_col_ptr(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_COL_PTR_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_COL_PTR_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_col_ptr(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_COL_PTR_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_COL_PTR_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_A_values(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_VALUES_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_VALUES_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_values(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_VALUES_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_VALUES_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_A_tile_nnz_counts(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_NNZ_COUNTS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_NNZ_COUNTS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_tile_nnz_counts(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_NNZ_COUNTS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_NNZ_COUNTS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_A_tile_nnz_offsets(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_NNZ_OFFSETS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_NNZ_OFFSETS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_tile_nnz_offsets(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_NNZ_OFFSETS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_NNZ_OFFSETS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_A_tile_col_offsets(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_COL_OFFSETS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_COL_OFFSETS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_tile_col_offsets(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_COL_OFFSETS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_TILE_COL_OFFSETS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_A_row_idx_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_ROW_IDX_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_ROW_IDX_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_row_idx_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_ROW_IDX_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_ROW_IDX_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_A_col_ptr_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_COL_PTR_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_COL_PTR_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_col_ptr_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_COL_PTR_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_COL_PTR_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_A_values_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_VALUES_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_VALUES_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_A_values_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_VALUES_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_A_VALUES_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_AT_tile_nnz_counts(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_COUNTS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_COUNTS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_AT_tile_nnz_counts(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_COUNTS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_COUNTS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_AT_tile_nnz_offsets(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_OFFSETS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_OFFSETS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_AT_tile_nnz_offsets(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_OFFSETS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_OFFSETS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_AT_tile_col_offsets(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_COL_OFFSETS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_COL_OFFSETS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_AT_tile_col_offsets(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_COL_OFFSETS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_TILE_COL_OFFSETS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_AT_row_idx_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_ROW_IDX_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_ROW_IDX_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_AT_row_idx_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_ROW_IDX_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_ROW_IDX_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_AT_col_ptr_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_COL_PTR_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_COL_PTR_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_AT_col_ptr_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_COL_PTR_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_COL_PTR_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_AT_values_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_VALUES_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_VALUES_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_AT_values_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_VALUES_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_AT_VALUES_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_P_tile_nnz_counts(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_NNZ_COUNTS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_NNZ_COUNTS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_P_tile_nnz_counts(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_NNZ_COUNTS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_NNZ_COUNTS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_P_tile_nnz_offsets(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_NNZ_OFFSETS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_NNZ_OFFSETS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_P_tile_nnz_offsets(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_NNZ_OFFSETS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_NNZ_OFFSETS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_P_tile_col_offsets(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_COL_OFFSETS_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_COL_OFFSETS_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_P_tile_col_offsets(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_COL_OFFSETS_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_TILE_COL_OFFSETS_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_P_row_idx_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_ROW_IDX_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_ROW_IDX_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_P_row_idx_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_ROW_IDX_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_ROW_IDX_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_P_col_ptr_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_COL_PTR_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_COL_PTR_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_P_col_ptr_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_COL_PTR_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_COL_PTR_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_P_values_tiled(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_VALUES_TILED_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_VALUES_TILED_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_P_values_tiled(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_VALUES_TILED_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_VALUES_TILED_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_P_diag(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_DIAG_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_DIAG_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_P_diag(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_DIAG_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_P_DIAG_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_l_in(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_L_IN_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_L_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_l_in(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_L_IN_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_L_IN_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_u_in(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_U_IN_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_U_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_u_in(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_U_IN_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_U_IN_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_q_in(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_Q_IN_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_Q_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_q_in(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_Q_IN_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_Q_IN_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_rho_in(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_RHO_IN_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_RHO_IN_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_rho_in(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_RHO_IN_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_RHO_IN_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_x_out(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_X_OUT_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_X_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_x_out(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_X_OUT_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_X_OUT_DATA + 4) << 32;
    return Data;
}

void XAdmm_Set_y_out(XAdmm *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_Y_OUT_DATA, (u32)(Data));
    XAdmm_WriteReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_Y_OUT_DATA + 4, (u32)(Data >> 32));
}

u64 XAdmm_Get_y_out(XAdmm *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_Y_OUT_DATA);
    Data += (u64)XAdmm_ReadReg(InstancePtr->Control_r_BaseAddress, XADMM_CONTROL_R_ADDR_Y_OUT_DATA + 4) << 32;
    return Data;
}

void XAdmm_InterruptGlobalEnable(XAdmm *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_GIE, 1);
}

void XAdmm_InterruptGlobalDisable(XAdmm *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_GIE, 0);
}

void XAdmm_InterruptEnable(XAdmm *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_IER);
    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_IER, Register | Mask);
}

void XAdmm_InterruptDisable(XAdmm *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_IER);
    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_IER, Register & (~Mask));
}

void XAdmm_InterruptClear(XAdmm *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XAdmm_WriteReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ISR, Mask);
}

u32 XAdmm_InterruptGetEnabled(XAdmm *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_IER);
}

u32 XAdmm_InterruptGetStatus(XAdmm *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XAdmm_ReadReg(InstancePtr->Control_BaseAddress, XADMM_CONTROL_ADDR_ISR);
}

