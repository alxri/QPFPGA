// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xadmm.h"

extern XAdmm_Config XAdmm_ConfigTable[];

#ifdef SDT
XAdmm_Config *XAdmm_LookupConfig(UINTPTR BaseAddress) {
	XAdmm_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XAdmm_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XAdmm_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XAdmm_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAdmm_Initialize(XAdmm *InstancePtr, UINTPTR BaseAddress) {
	XAdmm_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAdmm_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAdmm_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XAdmm_Config *XAdmm_LookupConfig(u16 DeviceId) {
	XAdmm_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XADMM_NUM_INSTANCES; Index++) {
		if (XAdmm_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XAdmm_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XAdmm_Initialize(XAdmm *InstancePtr, u16 DeviceId) {
	XAdmm_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XAdmm_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XAdmm_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

