// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XADMM_H
#define XADMM_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xadmm_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
} XAdmm_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u64 Control_r_BaseAddress;
    u32 IsReady;
} XAdmm;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XAdmm_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XAdmm_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XAdmm_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XAdmm_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XAdmm_Initialize(XAdmm *InstancePtr, UINTPTR BaseAddress);
XAdmm_Config* XAdmm_LookupConfig(UINTPTR BaseAddress);
#else
int XAdmm_Initialize(XAdmm *InstancePtr, u16 DeviceId);
XAdmm_Config* XAdmm_LookupConfig(u16 DeviceId);
#endif
int XAdmm_CfgInitialize(XAdmm *InstancePtr, XAdmm_Config *ConfigPtr);
#else
int XAdmm_Initialize(XAdmm *InstancePtr, const char* InstanceName);
int XAdmm_Release(XAdmm *InstancePtr);
#endif

void XAdmm_Start(XAdmm *InstancePtr);
u32 XAdmm_IsDone(XAdmm *InstancePtr);
u32 XAdmm_IsIdle(XAdmm *InstancePtr);
u32 XAdmm_IsReady(XAdmm *InstancePtr);
void XAdmm_EnableAutoRestart(XAdmm *InstancePtr);
void XAdmm_DisableAutoRestart(XAdmm *InstancePtr);

void XAdmm_Set_num_rows(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_num_rows(XAdmm *InstancePtr);
void XAdmm_Set_num_cols(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_num_cols(XAdmm *InstancePtr);
void XAdmm_Set_A_nnz(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_A_nnz(XAdmm *InstancePtr);
void XAdmm_Set_A_num_row_tiles(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_A_num_row_tiles(XAdmm *InstancePtr);
void XAdmm_Set_A_num_col_tiles(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_A_num_col_tiles(XAdmm *InstancePtr);
void XAdmm_Set_AT_num_row_tiles(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_AT_num_row_tiles(XAdmm *InstancePtr);
void XAdmm_Set_AT_num_col_tiles(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_AT_num_col_tiles(XAdmm *InstancePtr);
void XAdmm_Set_P_num_row_tiles(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_P_num_row_tiles(XAdmm *InstancePtr);
void XAdmm_Set_P_num_col_tiles(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_P_num_col_tiles(XAdmm *InstancePtr);
void XAdmm_Set_sigma(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_sigma(XAdmm *InstancePtr);
void XAdmm_Set_alpha(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_alpha(XAdmm *InstancePtr);
void XAdmm_Set_admm_max_iterations(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_admm_max_iterations(XAdmm *InstancePtr);
void XAdmm_Set_pcg_max_iterations(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_pcg_max_iterations(XAdmm *InstancePtr);
void XAdmm_Set_adaptive_rho(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_adaptive_rho(XAdmm *InstancePtr);
void XAdmm_Set_eps_abs(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_eps_abs(XAdmm *InstancePtr);
void XAdmm_Set_eps_rel(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_eps_rel(XAdmm *InstancePtr);
void XAdmm_Set_pcg_tol_fraction(XAdmm *InstancePtr, u32 Data);
u32 XAdmm_Get_pcg_tol_fraction(XAdmm *InstancePtr);
u32 XAdmm_Get_admm_num_iterations_out(XAdmm *InstancePtr);
u32 XAdmm_Get_admm_num_iterations_out_vld(XAdmm *InstancePtr);
u32 XAdmm_Get_pcg_num_iterations_out(XAdmm *InstancePtr);
u32 XAdmm_Get_pcg_num_iterations_out_vld(XAdmm *InstancePtr);
u32 XAdmm_Get_r_prim_out(XAdmm *InstancePtr);
u32 XAdmm_Get_r_prim_out_vld(XAdmm *InstancePtr);
u32 XAdmm_Get_r_dual_out(XAdmm *InstancePtr);
u32 XAdmm_Get_r_dual_out_vld(XAdmm *InstancePtr);
u32 XAdmm_Get_status_out(XAdmm *InstancePtr);
u32 XAdmm_Get_status_out_vld(XAdmm *InstancePtr);
void XAdmm_Set_A_row_idx(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_row_idx(XAdmm *InstancePtr);
void XAdmm_Set_A_col_ptr(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_col_ptr(XAdmm *InstancePtr);
void XAdmm_Set_A_values(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_values(XAdmm *InstancePtr);
void XAdmm_Set_A_tile_nnz_counts(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_tile_nnz_counts(XAdmm *InstancePtr);
void XAdmm_Set_A_tile_nnz_offsets(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_tile_nnz_offsets(XAdmm *InstancePtr);
void XAdmm_Set_A_tile_col_offsets(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_tile_col_offsets(XAdmm *InstancePtr);
void XAdmm_Set_A_row_idx_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_row_idx_tiled(XAdmm *InstancePtr);
void XAdmm_Set_A_col_ptr_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_col_ptr_tiled(XAdmm *InstancePtr);
void XAdmm_Set_A_values_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_A_values_tiled(XAdmm *InstancePtr);
void XAdmm_Set_AT_tile_nnz_counts(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_AT_tile_nnz_counts(XAdmm *InstancePtr);
void XAdmm_Set_AT_tile_nnz_offsets(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_AT_tile_nnz_offsets(XAdmm *InstancePtr);
void XAdmm_Set_AT_tile_col_offsets(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_AT_tile_col_offsets(XAdmm *InstancePtr);
void XAdmm_Set_AT_row_idx_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_AT_row_idx_tiled(XAdmm *InstancePtr);
void XAdmm_Set_AT_col_ptr_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_AT_col_ptr_tiled(XAdmm *InstancePtr);
void XAdmm_Set_AT_values_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_AT_values_tiled(XAdmm *InstancePtr);
void XAdmm_Set_P_tile_nnz_counts(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_P_tile_nnz_counts(XAdmm *InstancePtr);
void XAdmm_Set_P_tile_nnz_offsets(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_P_tile_nnz_offsets(XAdmm *InstancePtr);
void XAdmm_Set_P_tile_col_offsets(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_P_tile_col_offsets(XAdmm *InstancePtr);
void XAdmm_Set_P_row_idx_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_P_row_idx_tiled(XAdmm *InstancePtr);
void XAdmm_Set_P_col_ptr_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_P_col_ptr_tiled(XAdmm *InstancePtr);
void XAdmm_Set_P_values_tiled(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_P_values_tiled(XAdmm *InstancePtr);
void XAdmm_Set_P_diag(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_P_diag(XAdmm *InstancePtr);
void XAdmm_Set_l_in(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_l_in(XAdmm *InstancePtr);
void XAdmm_Set_u_in(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_u_in(XAdmm *InstancePtr);
void XAdmm_Set_q_in(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_q_in(XAdmm *InstancePtr);
void XAdmm_Set_rho_in(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_rho_in(XAdmm *InstancePtr);
void XAdmm_Set_x_out(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_x_out(XAdmm *InstancePtr);
void XAdmm_Set_y_out(XAdmm *InstancePtr, u64 Data);
u64 XAdmm_Get_y_out(XAdmm *InstancePtr);

void XAdmm_InterruptGlobalEnable(XAdmm *InstancePtr);
void XAdmm_InterruptGlobalDisable(XAdmm *InstancePtr);
void XAdmm_InterruptEnable(XAdmm *InstancePtr, u32 Mask);
void XAdmm_InterruptDisable(XAdmm *InstancePtr, u32 Mask);
void XAdmm_InterruptClear(XAdmm *InstancePtr, u32 Mask);
u32 XAdmm_InterruptGetEnabled(XAdmm *InstancePtr);
u32 XAdmm_InterruptGetStatus(XAdmm *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
