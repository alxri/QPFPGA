// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.2 (64-bit)
// Tool Version Limit: 2024.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
// control
// 0x00 : Control signals
//        bit 0  - ap_start (Read/Write/COH)
//        bit 1  - ap_done (Read/COR)
//        bit 2  - ap_idle (Read)
//        bit 3  - ap_ready (Read/COR)
//        bit 7  - auto_restart (Read/Write)
//        bit 9  - interrupt (Read)
//        others - reserved
// 0x04 : Global Interrupt Enable Register
//        bit 0  - Global Interrupt Enable (Read/Write)
//        others - reserved
// 0x08 : IP Interrupt Enable Register (Read/Write)
//        bit 0 - enable ap_done interrupt (Read/Write)
//        bit 1 - enable ap_ready interrupt (Read/Write)
//        others - reserved
// 0x0c : IP Interrupt Status Register (Read/TOW)
//        bit 0 - ap_done (Read/TOW)
//        bit 1 - ap_ready (Read/TOW)
//        others - reserved
// 0x10 : Data signal of num_rows
//        bit 31~0 - num_rows[31:0] (Read/Write)
// 0x14 : reserved
// 0x18 : Data signal of num_cols
//        bit 31~0 - num_cols[31:0] (Read/Write)
// 0x1c : reserved
// 0x20 : Data signal of A_nnz
//        bit 31~0 - A_nnz[31:0] (Read/Write)
// 0x24 : reserved
// 0x28 : Data signal of A_num_row_tiles
//        bit 31~0 - A_num_row_tiles[31:0] (Read/Write)
// 0x2c : reserved
// 0x30 : Data signal of A_num_col_tiles
//        bit 31~0 - A_num_col_tiles[31:0] (Read/Write)
// 0x34 : reserved
// 0x38 : Data signal of AT_num_row_tiles
//        bit 31~0 - AT_num_row_tiles[31:0] (Read/Write)
// 0x3c : reserved
// 0x40 : Data signal of AT_num_col_tiles
//        bit 31~0 - AT_num_col_tiles[31:0] (Read/Write)
// 0x44 : reserved
// 0x48 : Data signal of P_num_row_tiles
//        bit 31~0 - P_num_row_tiles[31:0] (Read/Write)
// 0x4c : reserved
// 0x50 : Data signal of P_num_col_tiles
//        bit 31~0 - P_num_col_tiles[31:0] (Read/Write)
// 0x54 : reserved
// 0x58 : Data signal of sigma
//        bit 31~0 - sigma[31:0] (Read/Write)
// 0x5c : reserved
// 0x60 : Data signal of alpha
//        bit 31~0 - alpha[31:0] (Read/Write)
// 0x64 : reserved
// 0x68 : Data signal of admm_max_iterations
//        bit 31~0 - admm_max_iterations[31:0] (Read/Write)
// 0x6c : reserved
// 0x70 : Data signal of pcg_max_iterations
//        bit 31~0 - pcg_max_iterations[31:0] (Read/Write)
// 0x74 : reserved
// 0x78 : Data signal of adaptive_rho
//        bit 0  - adaptive_rho[0] (Read/Write)
//        others - reserved
// 0x7c : reserved
// 0x80 : Data signal of eps_abs
//        bit 31~0 - eps_abs[31:0] (Read/Write)
// 0x84 : reserved
// 0x88 : Data signal of eps_rel
//        bit 31~0 - eps_rel[31:0] (Read/Write)
// 0x8c : reserved
// 0x90 : Data signal of pcg_tol_fraction
//        bit 31~0 - pcg_tol_fraction[31:0] (Read/Write)
// 0x94 : reserved
// 0x98 : Data signal of admm_num_iterations_out
//        bit 31~0 - admm_num_iterations_out[31:0] (Read)
// 0x9c : Control signal of admm_num_iterations_out
//        bit 0  - admm_num_iterations_out_ap_vld (Read/COR)
//        others - reserved
// 0xa8 : Data signal of pcg_num_iterations_out
//        bit 31~0 - pcg_num_iterations_out[31:0] (Read)
// 0xac : Control signal of pcg_num_iterations_out
//        bit 0  - pcg_num_iterations_out_ap_vld (Read/COR)
//        others - reserved
// 0xb8 : Data signal of r_prim_out
//        bit 31~0 - r_prim_out[31:0] (Read)
// 0xbc : Control signal of r_prim_out
//        bit 0  - r_prim_out_ap_vld (Read/COR)
//        others - reserved
// 0xc8 : Data signal of r_dual_out
//        bit 31~0 - r_dual_out[31:0] (Read)
// 0xcc : Control signal of r_dual_out
//        bit 0  - r_dual_out_ap_vld (Read/COR)
//        others - reserved
// 0xd8 : Data signal of status_out
//        bit 31~0 - status_out[31:0] (Read)
// 0xdc : Control signal of status_out
//        bit 0  - status_out_ap_vld (Read/COR)
//        others - reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XADMM_CONTROL_ADDR_AP_CTRL                      0x00
#define XADMM_CONTROL_ADDR_GIE                          0x04
#define XADMM_CONTROL_ADDR_IER                          0x08
#define XADMM_CONTROL_ADDR_ISR                          0x0c
#define XADMM_CONTROL_ADDR_NUM_ROWS_DATA                0x10
#define XADMM_CONTROL_BITS_NUM_ROWS_DATA                32
#define XADMM_CONTROL_ADDR_NUM_COLS_DATA                0x18
#define XADMM_CONTROL_BITS_NUM_COLS_DATA                32
#define XADMM_CONTROL_ADDR_A_NNZ_DATA                   0x20
#define XADMM_CONTROL_BITS_A_NNZ_DATA                   32
#define XADMM_CONTROL_ADDR_A_NUM_ROW_TILES_DATA         0x28
#define XADMM_CONTROL_BITS_A_NUM_ROW_TILES_DATA         32
#define XADMM_CONTROL_ADDR_A_NUM_COL_TILES_DATA         0x30
#define XADMM_CONTROL_BITS_A_NUM_COL_TILES_DATA         32
#define XADMM_CONTROL_ADDR_AT_NUM_ROW_TILES_DATA        0x38
#define XADMM_CONTROL_BITS_AT_NUM_ROW_TILES_DATA        32
#define XADMM_CONTROL_ADDR_AT_NUM_COL_TILES_DATA        0x40
#define XADMM_CONTROL_BITS_AT_NUM_COL_TILES_DATA        32
#define XADMM_CONTROL_ADDR_P_NUM_ROW_TILES_DATA         0x48
#define XADMM_CONTROL_BITS_P_NUM_ROW_TILES_DATA         32
#define XADMM_CONTROL_ADDR_P_NUM_COL_TILES_DATA         0x50
#define XADMM_CONTROL_BITS_P_NUM_COL_TILES_DATA         32
#define XADMM_CONTROL_ADDR_SIGMA_DATA                   0x58
#define XADMM_CONTROL_BITS_SIGMA_DATA                   32
#define XADMM_CONTROL_ADDR_ALPHA_DATA                   0x60
#define XADMM_CONTROL_BITS_ALPHA_DATA                   32
#define XADMM_CONTROL_ADDR_ADMM_MAX_ITERATIONS_DATA     0x68
#define XADMM_CONTROL_BITS_ADMM_MAX_ITERATIONS_DATA     32
#define XADMM_CONTROL_ADDR_PCG_MAX_ITERATIONS_DATA      0x70
#define XADMM_CONTROL_BITS_PCG_MAX_ITERATIONS_DATA      32
#define XADMM_CONTROL_ADDR_ADAPTIVE_RHO_DATA            0x78
#define XADMM_CONTROL_BITS_ADAPTIVE_RHO_DATA            1
#define XADMM_CONTROL_ADDR_EPS_ABS_DATA                 0x80
#define XADMM_CONTROL_BITS_EPS_ABS_DATA                 32
#define XADMM_CONTROL_ADDR_EPS_REL_DATA                 0x88
#define XADMM_CONTROL_BITS_EPS_REL_DATA                 32
#define XADMM_CONTROL_ADDR_PCG_TOL_FRACTION_DATA        0x90
#define XADMM_CONTROL_BITS_PCG_TOL_FRACTION_DATA        32
#define XADMM_CONTROL_ADDR_ADMM_NUM_ITERATIONS_OUT_DATA 0x98
#define XADMM_CONTROL_BITS_ADMM_NUM_ITERATIONS_OUT_DATA 32
#define XADMM_CONTROL_ADDR_ADMM_NUM_ITERATIONS_OUT_CTRL 0x9c
#define XADMM_CONTROL_ADDR_PCG_NUM_ITERATIONS_OUT_DATA  0xa8
#define XADMM_CONTROL_BITS_PCG_NUM_ITERATIONS_OUT_DATA  32
#define XADMM_CONTROL_ADDR_PCG_NUM_ITERATIONS_OUT_CTRL  0xac
#define XADMM_CONTROL_ADDR_R_PRIM_OUT_DATA              0xb8
#define XADMM_CONTROL_BITS_R_PRIM_OUT_DATA              32
#define XADMM_CONTROL_ADDR_R_PRIM_OUT_CTRL              0xbc
#define XADMM_CONTROL_ADDR_R_DUAL_OUT_DATA              0xc8
#define XADMM_CONTROL_BITS_R_DUAL_OUT_DATA              32
#define XADMM_CONTROL_ADDR_R_DUAL_OUT_CTRL              0xcc
#define XADMM_CONTROL_ADDR_STATUS_OUT_DATA              0xd8
#define XADMM_CONTROL_BITS_STATUS_OUT_DATA              32
#define XADMM_CONTROL_ADDR_STATUS_OUT_CTRL              0xdc

// control_r
// 0x000 : reserved
// 0x004 : reserved
// 0x008 : reserved
// 0x00c : reserved
// 0x010 : Data signal of A_row_idx
//         bit 31~0 - A_row_idx[31:0] (Read/Write)
// 0x014 : Data signal of A_row_idx
//         bit 31~0 - A_row_idx[63:32] (Read/Write)
// 0x018 : reserved
// 0x01c : Data signal of A_col_ptr
//         bit 31~0 - A_col_ptr[31:0] (Read/Write)
// 0x020 : Data signal of A_col_ptr
//         bit 31~0 - A_col_ptr[63:32] (Read/Write)
// 0x024 : reserved
// 0x028 : Data signal of A_values
//         bit 31~0 - A_values[31:0] (Read/Write)
// 0x02c : Data signal of A_values
//         bit 31~0 - A_values[63:32] (Read/Write)
// 0x030 : reserved
// 0x034 : Data signal of A_tile_nnz_counts
//         bit 31~0 - A_tile_nnz_counts[31:0] (Read/Write)
// 0x038 : Data signal of A_tile_nnz_counts
//         bit 31~0 - A_tile_nnz_counts[63:32] (Read/Write)
// 0x03c : reserved
// 0x040 : Data signal of A_tile_nnz_offsets
//         bit 31~0 - A_tile_nnz_offsets[31:0] (Read/Write)
// 0x044 : Data signal of A_tile_nnz_offsets
//         bit 31~0 - A_tile_nnz_offsets[63:32] (Read/Write)
// 0x048 : reserved
// 0x04c : Data signal of A_tile_col_offsets
//         bit 31~0 - A_tile_col_offsets[31:0] (Read/Write)
// 0x050 : Data signal of A_tile_col_offsets
//         bit 31~0 - A_tile_col_offsets[63:32] (Read/Write)
// 0x054 : reserved
// 0x058 : Data signal of A_row_idx_tiled
//         bit 31~0 - A_row_idx_tiled[31:0] (Read/Write)
// 0x05c : Data signal of A_row_idx_tiled
//         bit 31~0 - A_row_idx_tiled[63:32] (Read/Write)
// 0x060 : reserved
// 0x064 : Data signal of A_col_ptr_tiled
//         bit 31~0 - A_col_ptr_tiled[31:0] (Read/Write)
// 0x068 : Data signal of A_col_ptr_tiled
//         bit 31~0 - A_col_ptr_tiled[63:32] (Read/Write)
// 0x06c : reserved
// 0x070 : Data signal of A_values_tiled
//         bit 31~0 - A_values_tiled[31:0] (Read/Write)
// 0x074 : Data signal of A_values_tiled
//         bit 31~0 - A_values_tiled[63:32] (Read/Write)
// 0x078 : reserved
// 0x07c : Data signal of AT_tile_nnz_counts
//         bit 31~0 - AT_tile_nnz_counts[31:0] (Read/Write)
// 0x080 : Data signal of AT_tile_nnz_counts
//         bit 31~0 - AT_tile_nnz_counts[63:32] (Read/Write)
// 0x084 : reserved
// 0x088 : Data signal of AT_tile_nnz_offsets
//         bit 31~0 - AT_tile_nnz_offsets[31:0] (Read/Write)
// 0x08c : Data signal of AT_tile_nnz_offsets
//         bit 31~0 - AT_tile_nnz_offsets[63:32] (Read/Write)
// 0x090 : reserved
// 0x094 : Data signal of AT_tile_col_offsets
//         bit 31~0 - AT_tile_col_offsets[31:0] (Read/Write)
// 0x098 : Data signal of AT_tile_col_offsets
//         bit 31~0 - AT_tile_col_offsets[63:32] (Read/Write)
// 0x09c : reserved
// 0x0a0 : Data signal of AT_row_idx_tiled
//         bit 31~0 - AT_row_idx_tiled[31:0] (Read/Write)
// 0x0a4 : Data signal of AT_row_idx_tiled
//         bit 31~0 - AT_row_idx_tiled[63:32] (Read/Write)
// 0x0a8 : reserved
// 0x0ac : Data signal of AT_col_ptr_tiled
//         bit 31~0 - AT_col_ptr_tiled[31:0] (Read/Write)
// 0x0b0 : Data signal of AT_col_ptr_tiled
//         bit 31~0 - AT_col_ptr_tiled[63:32] (Read/Write)
// 0x0b4 : reserved
// 0x0b8 : Data signal of AT_values_tiled
//         bit 31~0 - AT_values_tiled[31:0] (Read/Write)
// 0x0bc : Data signal of AT_values_tiled
//         bit 31~0 - AT_values_tiled[63:32] (Read/Write)
// 0x0c0 : reserved
// 0x0c4 : Data signal of P_tile_nnz_counts
//         bit 31~0 - P_tile_nnz_counts[31:0] (Read/Write)
// 0x0c8 : Data signal of P_tile_nnz_counts
//         bit 31~0 - P_tile_nnz_counts[63:32] (Read/Write)
// 0x0cc : reserved
// 0x0d0 : Data signal of P_tile_nnz_offsets
//         bit 31~0 - P_tile_nnz_offsets[31:0] (Read/Write)
// 0x0d4 : Data signal of P_tile_nnz_offsets
//         bit 31~0 - P_tile_nnz_offsets[63:32] (Read/Write)
// 0x0d8 : reserved
// 0x0dc : Data signal of P_tile_col_offsets
//         bit 31~0 - P_tile_col_offsets[31:0] (Read/Write)
// 0x0e0 : Data signal of P_tile_col_offsets
//         bit 31~0 - P_tile_col_offsets[63:32] (Read/Write)
// 0x0e4 : reserved
// 0x0e8 : Data signal of P_row_idx_tiled
//         bit 31~0 - P_row_idx_tiled[31:0] (Read/Write)
// 0x0ec : Data signal of P_row_idx_tiled
//         bit 31~0 - P_row_idx_tiled[63:32] (Read/Write)
// 0x0f0 : reserved
// 0x0f4 : Data signal of P_col_ptr_tiled
//         bit 31~0 - P_col_ptr_tiled[31:0] (Read/Write)
// 0x0f8 : Data signal of P_col_ptr_tiled
//         bit 31~0 - P_col_ptr_tiled[63:32] (Read/Write)
// 0x0fc : reserved
// 0x100 : Data signal of P_values_tiled
//         bit 31~0 - P_values_tiled[31:0] (Read/Write)
// 0x104 : Data signal of P_values_tiled
//         bit 31~0 - P_values_tiled[63:32] (Read/Write)
// 0x108 : reserved
// 0x10c : Data signal of P_diag
//         bit 31~0 - P_diag[31:0] (Read/Write)
// 0x110 : Data signal of P_diag
//         bit 31~0 - P_diag[63:32] (Read/Write)
// 0x114 : reserved
// 0x118 : Data signal of l_in
//         bit 31~0 - l_in[31:0] (Read/Write)
// 0x11c : Data signal of l_in
//         bit 31~0 - l_in[63:32] (Read/Write)
// 0x120 : reserved
// 0x124 : Data signal of u_in
//         bit 31~0 - u_in[31:0] (Read/Write)
// 0x128 : Data signal of u_in
//         bit 31~0 - u_in[63:32] (Read/Write)
// 0x12c : reserved
// 0x130 : Data signal of q_in
//         bit 31~0 - q_in[31:0] (Read/Write)
// 0x134 : Data signal of q_in
//         bit 31~0 - q_in[63:32] (Read/Write)
// 0x138 : reserved
// 0x13c : Data signal of rho_in
//         bit 31~0 - rho_in[31:0] (Read/Write)
// 0x140 : Data signal of rho_in
//         bit 31~0 - rho_in[63:32] (Read/Write)
// 0x144 : reserved
// 0x148 : Data signal of x_out
//         bit 31~0 - x_out[31:0] (Read/Write)
// 0x14c : Data signal of x_out
//         bit 31~0 - x_out[63:32] (Read/Write)
// 0x150 : reserved
// 0x154 : Data signal of y_out
//         bit 31~0 - y_out[31:0] (Read/Write)
// 0x158 : Data signal of y_out
//         bit 31~0 - y_out[63:32] (Read/Write)
// 0x15c : reserved
// (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

#define XADMM_CONTROL_R_ADDR_A_ROW_IDX_DATA           0x010
#define XADMM_CONTROL_R_BITS_A_ROW_IDX_DATA           64
#define XADMM_CONTROL_R_ADDR_A_COL_PTR_DATA           0x01c
#define XADMM_CONTROL_R_BITS_A_COL_PTR_DATA           64
#define XADMM_CONTROL_R_ADDR_A_VALUES_DATA            0x028
#define XADMM_CONTROL_R_BITS_A_VALUES_DATA            64
#define XADMM_CONTROL_R_ADDR_A_TILE_NNZ_COUNTS_DATA   0x034
#define XADMM_CONTROL_R_BITS_A_TILE_NNZ_COUNTS_DATA   64
#define XADMM_CONTROL_R_ADDR_A_TILE_NNZ_OFFSETS_DATA  0x040
#define XADMM_CONTROL_R_BITS_A_TILE_NNZ_OFFSETS_DATA  64
#define XADMM_CONTROL_R_ADDR_A_TILE_COL_OFFSETS_DATA  0x04c
#define XADMM_CONTROL_R_BITS_A_TILE_COL_OFFSETS_DATA  64
#define XADMM_CONTROL_R_ADDR_A_ROW_IDX_TILED_DATA     0x058
#define XADMM_CONTROL_R_BITS_A_ROW_IDX_TILED_DATA     64
#define XADMM_CONTROL_R_ADDR_A_COL_PTR_TILED_DATA     0x064
#define XADMM_CONTROL_R_BITS_A_COL_PTR_TILED_DATA     64
#define XADMM_CONTROL_R_ADDR_A_VALUES_TILED_DATA      0x070
#define XADMM_CONTROL_R_BITS_A_VALUES_TILED_DATA      64
#define XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_COUNTS_DATA  0x07c
#define XADMM_CONTROL_R_BITS_AT_TILE_NNZ_COUNTS_DATA  64
#define XADMM_CONTROL_R_ADDR_AT_TILE_NNZ_OFFSETS_DATA 0x088
#define XADMM_CONTROL_R_BITS_AT_TILE_NNZ_OFFSETS_DATA 64
#define XADMM_CONTROL_R_ADDR_AT_TILE_COL_OFFSETS_DATA 0x094
#define XADMM_CONTROL_R_BITS_AT_TILE_COL_OFFSETS_DATA 64
#define XADMM_CONTROL_R_ADDR_AT_ROW_IDX_TILED_DATA    0x0a0
#define XADMM_CONTROL_R_BITS_AT_ROW_IDX_TILED_DATA    64
#define XADMM_CONTROL_R_ADDR_AT_COL_PTR_TILED_DATA    0x0ac
#define XADMM_CONTROL_R_BITS_AT_COL_PTR_TILED_DATA    64
#define XADMM_CONTROL_R_ADDR_AT_VALUES_TILED_DATA     0x0b8
#define XADMM_CONTROL_R_BITS_AT_VALUES_TILED_DATA     64
#define XADMM_CONTROL_R_ADDR_P_TILE_NNZ_COUNTS_DATA   0x0c4
#define XADMM_CONTROL_R_BITS_P_TILE_NNZ_COUNTS_DATA   64
#define XADMM_CONTROL_R_ADDR_P_TILE_NNZ_OFFSETS_DATA  0x0d0
#define XADMM_CONTROL_R_BITS_P_TILE_NNZ_OFFSETS_DATA  64
#define XADMM_CONTROL_R_ADDR_P_TILE_COL_OFFSETS_DATA  0x0dc
#define XADMM_CONTROL_R_BITS_P_TILE_COL_OFFSETS_DATA  64
#define XADMM_CONTROL_R_ADDR_P_ROW_IDX_TILED_DATA     0x0e8
#define XADMM_CONTROL_R_BITS_P_ROW_IDX_TILED_DATA     64
#define XADMM_CONTROL_R_ADDR_P_COL_PTR_TILED_DATA     0x0f4
#define XADMM_CONTROL_R_BITS_P_COL_PTR_TILED_DATA     64
#define XADMM_CONTROL_R_ADDR_P_VALUES_TILED_DATA      0x100
#define XADMM_CONTROL_R_BITS_P_VALUES_TILED_DATA      64
#define XADMM_CONTROL_R_ADDR_P_DIAG_DATA              0x10c
#define XADMM_CONTROL_R_BITS_P_DIAG_DATA              64
#define XADMM_CONTROL_R_ADDR_L_IN_DATA                0x118
#define XADMM_CONTROL_R_BITS_L_IN_DATA                64
#define XADMM_CONTROL_R_ADDR_U_IN_DATA                0x124
#define XADMM_CONTROL_R_BITS_U_IN_DATA                64
#define XADMM_CONTROL_R_ADDR_Q_IN_DATA                0x130
#define XADMM_CONTROL_R_BITS_Q_IN_DATA                64
#define XADMM_CONTROL_R_ADDR_RHO_IN_DATA              0x13c
#define XADMM_CONTROL_R_BITS_RHO_IN_DATA              64
#define XADMM_CONTROL_R_ADDR_X_OUT_DATA               0x148
#define XADMM_CONTROL_R_BITS_X_OUT_DATA               64
#define XADMM_CONTROL_R_ADDR_Y_OUT_DATA               0x154
#define XADMM_CONTROL_R_BITS_Y_OUT_DATA               64

